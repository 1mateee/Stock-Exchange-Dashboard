import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Typography,
  List,
  ListItem,
  Chip,
  CircularProgress
} from '@mui/material';
import { Event } from '@mui/icons-material';

const API_URL = 'http://localhost:5055/api/earnings';

function EarningsCalendar() {
  const [earnings, setEarnings] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchEarnings = async () => {
      setLoading(true);
      try {
        const response = await axios.get(API_URL);
        // Itt most már csak a valódi adatokat töltjük be
        setEarnings(response.data || []);
      } catch (error) {
        console.error('Error loading earnings:', error);
        // Hiba esetén üres listát mutatunk, nem mock adatot
        setEarnings([]);
      } finally {
        setLoading(false);
      }
    };

    fetchEarnings();
  }, []);

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('hu-HU', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    }) + '.';
  };

  return (
    // UI ELRENDEZÉS MEGTARTVA (px: 1)
    <Box sx={{ px: 1, pb: 2, pt: 2 }}>
      
      <Typography variant="h6" sx={{
        color: 'white',
        mb: 2,
        display: 'flex',
        alignItems: 'center',
        gap: 1,
        px: 1 // Címsor igazítása
      }}>
        <Event sx={{ color: '#4caf50' }} />
        Upcoming Earnings
      </Typography>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
          <CircularProgress sx={{ color: '#4caf50' }} />
        </Box>
      ) : earnings.length === 0 ? (
        <Typography variant="body2" sx={{ color: '#9e9e9e', textAlign: 'center', py: 2 }}>
          No upcoming earnings found.
        </Typography>
      ) : (
        <List sx={{ p: 0 }}>
          {earnings.map((item, index) => (
            <ListItem
              key={index}
              sx={{
                // KÁRTYA STÍLUS MEGTARTVA (px: 2)
                px: 2,
                py: 1.5,
                borderRadius: 2,
                mb: 1,
                bgcolor: '#242742',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'flex-start'
              }}
            >
              {/* Felső sor: Szimbólum és Dátum */}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', mb: 0.5 }}>
                <Typography variant="h6" sx={{ color: 'white', fontWeight: 600 }}>
                  {item.symbol}
                </Typography>
                <Typography variant="body2" sx={{ color: 'white' }}>
                  {formatDate(item.reportDate)}
                </Typography>
              </Box>

              {/* Alsó sor: Cég neve és Időzítés */}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
                <Typography variant="body2" sx={{ color: '#9e9e9e' }}>
                  {item.name || item.companyName}
                </Typography>
                <Chip 
                  label={item.time || 'Market Close'} 
                  size="small"
                  sx={{ 
                    bgcolor: 'rgba(244, 67, 54, 0.1)', 
                    color: '#f44336', 
                    border: '1px solid rgba(244, 67, 54, 0.2)',
                    height: '24px',
                    fontSize: '0.75rem'
                  }} 
                />
              </Box>
            </ListItem>
          ))}
        </List>
      )}
    </Box>
  );
}

export default EarningsCalendar;