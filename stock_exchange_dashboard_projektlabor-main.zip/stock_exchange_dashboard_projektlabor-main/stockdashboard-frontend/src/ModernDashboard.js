import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  IconButton,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Alert,
  Snackbar,
  Fade,
  Tabs,
  Tab,
  AppBar
} from '@mui/material';
import {
  TrendingUp,
  TrendingDown,
  Delete as DeleteIcon,
  ShowChart,
  Notifications,
  AccountBalance,
  Favorite,
  FavoriteBorder,
  Event,
  RssFeed
} from '@mui/icons-material';
import { HubConnectionBuilder, HttpTransportType } from '@microsoft/signalr';
import StockChart from './StockChart';
import AlertCreationForm from './AlertCreationForm';
import axios from 'axios';
import EarningsCalendar from './EarningsCalendar';
import CompanyNews from './CompanyNews';

const SIGNALR_URL = 'http://localhost:5055/hubs/stock';
const ALERTS_API_URL = 'http://localhost:5055/api/alerts';

function ModernDashboard() {
  const [stocks, setStocks] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [selectedSymbols, setSelectedSymbols] = useState([]);
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem('favorites') || '{}'); } catch { return {}; }
  });
  const [hiddenSymbols, setHiddenSymbols] = useState(() => {
    try { return new Set(JSON.parse(localStorage.getItem('hiddenSymbols') || '[]')); } catch { return new Set(); }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  const [loading, setLoading] = useState(true);
  
  const [rightTab, setRightTab] = useState(0);

  const showNotification = useCallback((message, severity = 'info') => {
    setNotification({ open: true, message, severity });
  }, []);

  const loadAlerts = useCallback(async () => {
    try {
      const response = await axios.get(ALERTS_API_URL);
      setAlerts(response.data);
    } catch (error) {
      console.error('Error loading alerts:', error);
      showNotification('Error loading alerts', 'error');
    }
  }, [showNotification]);

  const loadInitialStocks = useCallback(async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5055/api/stocks');
      
      if (response.data && response.data.length > 0) {
        const currentHidden = hiddenSymbols instanceof Set ? hiddenSymbols : new Set(hiddenSymbols);
        setStocks(response.data.filter(s => !currentHidden.has(s.symbol)));
      } else {
        const stockPromises = selectedSymbols.map(async (symbol) => {
          try {
            const response = await axios.get(`http://localhost:5055/api/stocks/${symbol}`);
            return response.data;
          } catch (error) {
            console.error(`Error loading stock ${symbol}:`, error);
            return null;
          }
        });

        const stockResults = await Promise.all(stockPromises);
        const currentHidden = hiddenSymbols instanceof Set ? hiddenSymbols : new Set(hiddenSymbols);
        const validStocks = stockResults.filter(stock => stock !== null && !currentHidden.has(stock.symbol));
        
        if (validStocks.length > 0) {
          setStocks(validStocks);
        }
      }
    } catch (error) {
      console.error('Error loading initial stocks:', error);
    } finally {
      setLoading(false);
    }
  }, [selectedSymbols, hiddenSymbols]);

  useEffect(() => {
    try { localStorage.setItem('favorites', JSON.stringify(favorites)); } catch {}
  }, [favorites]);

  useEffect(() => {
    try { localStorage.setItem('selectedSymbols', JSON.stringify(selectedSymbols)); } catch {}
  }, [selectedSymbols]);

  useEffect(() => {
    try { localStorage.setItem('hiddenSymbols', JSON.stringify(Array.from(hiddenSymbols))); } catch {}
  }, [hiddenSymbols]);

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem('selectedSymbols') || 'null');
      if (Array.isArray(stored) && stored.length) setSelectedSymbols(stored);
    } catch {}
  }, []);

  const toggleFavorite = (symbol) => {
    setFavorites(prev => ({ ...prev, [symbol]: !prev[symbol] }));
  };

  const removeFromList = (symbol) => {
    setHiddenSymbols(prev => new Set([...Array.from(prev), symbol]));
    setStocks(prev => prev.filter(s => s.symbol !== symbol));
    setSelectedSymbols(prev => prev.filter(s => s !== symbol));
    showNotification(`${symbol} removed from list`, 'info');
  };

  const addSymbol = async (symbol) => {
    const upper = (symbol || '').toUpperCase().trim();
    if (!upper) return;
    try {
      const res = await axios.get(`http://localhost:5055/api/stocks/${upper}`);
      const stock = res.data;
      setHiddenSymbols(prev => { const n = new Set(Array.from(prev)); n.delete(upper); return n; });
      setStocks(prev => prev.some(s => s.symbol === upper) ? prev : [...prev, stock]);
      setSelectedSymbols(prev => prev.includes(upper) ? prev : [...prev, upper]);
      setSearchQuery('');
      setSearchResults([]);
      showNotification(`${upper} added`, 'success');
    } catch (err) {
      console.error('Could not add symbol', err);
      showNotification(`Could not load ${upper}`, 'error');
    }
  };

  const searchStocks = async (q) => {
    if (!q || q.length < 2) { setSearchResults([]); return; }
    try {
      const res = await axios.get(`http://localhost:5055/api/stocks/search/${encodeURIComponent(q)}`);
      setSearchResults(res.data || []);
    } catch {
      setSearchResults([]);
    }
  };

  const deleteAlert = async (alertId) => {
    try {
      await axios.delete(`${ALERTS_API_URL}/${alertId}`);
      setAlerts(prev => prev.filter(alert => alert.id !== alertId));
      showNotification('Alert deleted successfully', 'success');
    } catch (error) {
      console.error('Error deleting alert:', error);
      showNotification('Error deleting alert', 'error');
    }
  };

  const handleCloseNotification = () => {
    setNotification(prev => ({ ...prev, open: false }));
  };

  useEffect(() => {
    const connection = new HubConnectionBuilder()
      .withUrl(SIGNALR_URL, { skipNegotiation: true, transport: HttpTransportType.WebSockets })
      .withAutomaticReconnect({
        nextRetryDelayInMilliseconds: (ctx) => Math.min(10000, (ctx.previousRetryCount + 1) * 1000)
      })
      .build();

    connection.on("StockUpdate", (stock) => {
      setStocks((prevStocks) => {
        const existingIndex = prevStocks.findIndex(s => s.symbol === stock.symbol);
        if (existingIndex >= 0) {
          const newStocks = [...prevStocks];
          newStocks[existingIndex] = stock;
          return newStocks;
        } else {
          return [...prevStocks, stock];
        }
      });
    });

    connection.on("AlertTriggered", (alert) => {
      showNotification(`Alert triggered: ${alert.symbol} ${alert.condition || ''} ${alert.targetPrice}`, 'warning');
      if (typeof Notification !== 'undefined' && Notification.permission === "granted") {
        new Notification(`Stock Alert: ${alert.symbol}`, {
          body: `${alert.symbol} hit target price`,
          icon: '/favicon.ico'
        });
      }
      setAlerts((prev) => prev.map(a =>
        a.id === alert.id ? { ...a, isActive: false, triggeredAt: alert.triggeredAt } : a
      ));
    });

    let isDisposed = false;
    let retryHandle = null;

    const start = async () => {
      if (isDisposed) return;
      if (connection.state === 'Connected' || connection.state === 'Connecting') return;
      try {
        await connection.start();
        await connection.invoke("JoinAllStocksGroup").catch(console.error);
      } catch (error) {
        if (!isDisposed) {
          retryHandle = setTimeout(start, 2000);
        }
      }
    };

    start();

    if (typeof Notification !== 'undefined' && Notification.permission === "default") {
      Notification.requestPermission();
    }

    loadInitialStocks();
    loadAlerts();

    return () => {
      isDisposed = true;
      if (retryHandle) clearTimeout(retryHandle);
      connection.stop().catch(() => { });
    };
  }, [loadInitialStocks, loadAlerts, showNotification]);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const formatChange = (change, changePercent) => {
    const isPositive = change >= 0;
    return {
      text: `${isPositive ? '+' : ''}${change.toFixed(2)} (${isPositive ? '+' : ''}${changePercent.toFixed(2)}%)`,
      color: isPositive ? '#4caf50' : '#f44336',
      icon: isPositive ? <TrendingUp /> : <TrendingDown />
    };
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      bgcolor: '#0a0e1a',
      color: 'white',
      px: { xs: 2, md: 4 }, // Szimmetrikus padding (bal és jobb is 2 vagy 4)
      py: 3,
      width: '100%',
      maxWidth: '100%',
      overflowX: 'hidden'
    }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{
          fontWeight: 700,
          color: 'white',
          mb: 1,
          display: 'flex',
          alignItems: 'center',
          gap: 2
        }}>
          <AccountBalance sx={{ color: '#64b5f6' }} />
          Stock Market Dashboard
        </Typography>
        <Typography variant="subtitle1" sx={{ color: '#9e9e9e' }}>
          Real-time stock monitoring and alerts
        </Typography>
      </Box>

      <Box sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', md: '2.5fr 4fr minmax(320px, 2fr)' },
        gap: 3,
        alignItems: 'flex-start',
        width: '100%',
        maxWidth: '100%',
        boxSizing: 'border-box'
      }}>
        {/* Left Column - All stocks list */}
        <Box sx={{ minWidth: 0 }}>
          <Card sx={{
            bgcolor: '#1a1d2e',
            borderRadius: 3,
            border: '1px solid #2a2d3d',
            height: { xs: 'auto', md: 'calc(100vh - 200px)' },
            display: 'flex',
            flexDirection: 'column'
          }}>
            <CardContent sx={{ pb: 1 }}>
              <Typography variant="h6" sx={{
                color: 'white',
                mb: 2,
                display: 'flex',
                alignItems: 'center',
                gap: 1
              }}>
                <TrendingUp sx={{ color: '#4caf50' }} />
                Stocks
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                <input
                  type="text"
                  placeholder="Search or add (e.g. TSLA)"
                  value={searchQuery}
                  onChange={(e) => { const v = e.target.value; setSearchQuery(v); searchStocks(v); }}
                  onKeyDown={(e) => { if (e.key === 'Enter') addSymbol(searchQuery); }}
                  style={{
                    flex: 1,
                    background: '#0f1324',
                    color: 'white',
                    border: '1px solid #2a2d3d',
                    borderRadius: 8,
                    padding: '10px 12px',
                    outline: 'none'
                  }}
                />
                <button
                  onClick={() => addSymbol(searchQuery)}
                  style={{
                    background: '#64b5f6', color: '#0a0e1a', border: 'none', borderRadius: 8,
                    padding: '10px 14px', fontWeight: 600, cursor: 'pointer'
                  }}
                >Add</button>
              </Box>
              {searchResults.length > 0 && (
                <Box sx={{ background: '#0f1324', border: '1px solid #2a2d3d', borderRadius: 2, maxHeight: 200, overflow: 'auto', mb: 1 }}>
                  <List dense sx={{ p: 0 }}>
                    {searchResults.slice(0, 8).map(sug => (
                      <ListItem key={sug.symbol} onClick={() => addSymbol(sug.symbol)} sx={{ cursor: 'pointer', '&:hover': { bgcolor: '#1a1d2e' } }}>
                        <ListItemText 
                          primary={<Typography sx={{ color: 'white' }}>{sug.symbol}</Typography>}
                          secondary={<Typography sx={{ color: '#9e9e9e' }}>{sug.companyName || sug.description || ''}</Typography>}
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </CardContent>

            <Box sx={{
              flex: 1,
              overflow: 'auto',
              px: 2,
              pb: 2,
              '&::-webkit-scrollbar': { width: '8px' },
              '&::-webkit-scrollbar-track': { background: '#1a1d2e' },
              '&::-webkit-scrollbar-thumb': { background: '#2a2d3d', borderRadius: '4px' },
              '&::-webkit-scrollbar-thumb:hover': { background: '#64b5f6' },
            }}>
              <List sx={{ p: 0 }}>
                {loading ? (
                  <ListItem sx={{ justifyContent: 'center' }}>
                    <Typography variant="body2" sx={{ color: '#9e9e9e' }}>Loading stocks...</Typography>
                  </ListItem>
                ) : stocks.length > 0 ? (
                  [...stocks]
                    .sort((a, b) => {
                      const af = favorites[a.symbol] ? 1 : 0;
                      const bf = favorites[b.symbol] ? 1 : 0;
                      if (bf !== af) return bf - af;
                      return a.symbol.localeCompare(b.symbol);
                    })
                    .map((stock) => {
                    const changeData = formatChange(stock.change, stock.changePercent);
                    const isSelected = selectedSymbols.includes(stock.symbol);
                    return (
                      <ListItem
                        key={stock.symbol}
                        sx={{
                          px: 0,
                          py: 1.5,
                          borderRadius: 2,
                          mb: 1,
                          bgcolor: isSelected ? '#2e335a' : '#242742',
                          '&:hover': { bgcolor: '#2a2d4a' }
                        }}
                        onClick={() => {
                          setSelectedSymbols(prev => prev.includes(stock.symbol)
                            ? prev.filter(s => s !== stock.symbol)
                            : [...prev, stock.symbol]
                          );
                        }}
                      >
                        <ListItemText
                          disableTypography
                          primary={
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <Typography variant="h6" sx={{ color: 'white', fontWeight: 600 }}>{stock.symbol}</Typography>
                              <Typography variant="h6" sx={{ color: 'white', fontWeight: 600 }}>{formatPrice(stock.currentPrice)}</Typography>
                            </Box>
                          }
                          secondary={
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 0.5 }}>
                              <Typography variant="body2" sx={{ color: '#9e9e9e' }}>{stock.companyName}</Typography>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                {changeData.icon}
                                <Typography variant="body2" sx={{ color: changeData.color, fontWeight: 500 }}>{changeData.text}</Typography>
                              </Box>
                            </Box>
                          }
                        />
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: 1 }}>
                          {isSelected && <Chip label="Selected" size="small" sx={{ bgcolor: '#64b5f6', color: '#0a0e1a' }} />}
                          <IconButton 
                            size="small"
                            onClick={(e) => { e.stopPropagation(); toggleFavorite(stock.symbol); }}
                            sx={{ color: favorites[stock.symbol] ? '#ff4081' : '#9e9e9e', '&:hover': { bgcolor: 'rgba(255,255,255,0.08)' } }}
                          >
                            {favorites[stock.symbol] ? <Favorite fontSize="small" /> : <FavoriteBorder fontSize="small" />}
                          </IconButton>
                          <IconButton 
                            size="small"
                            onClick={(e) => { e.stopPropagation(); removeFromList(stock.symbol); }}
                            sx={{ color: '#f44336', '&:hover': { bgcolor: 'rgba(244,67,54,0.1)' } }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      </ListItem>
                    );
                  })
                ) : (
                  <ListItem sx={{ justifyContent: 'center' }}>
                    <Typography variant="body2" sx={{ color: '#9e9e9e' }}>No stocks available</Typography>
                  </ListItem>
                )}
              </List>
            </Box>
          </Card>
        </Box>

        {/* Middle Column - Price Chart */}
        <Box sx={{ minWidth: 0 }}>
          <Card sx={{
            bgcolor: '#1a1d2e',
            borderRadius: 3,
            border: '1px solid #2a2d3d',
            mb: 3,
            height: { xs: 'auto', md: 'calc(100vh - 200px)' },
            display: 'flex',
            flexDirection: 'column'
          }}>
            <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <Typography variant="h6" sx={{
                color: 'white',
                mb: 2,
                display: 'flex',
                alignItems: 'center',
                gap: 1
              }}>
                <ShowChart sx={{ color: '#64b5f6' }} />
                Price History
              </Typography>
              <StockChart selectedSymbols={selectedSymbols} />
            </CardContent>
          </Card>
        </Box>

        {/* Right Column - Alerts, Events, News stacked */}
        <Box sx={{ 
          // JAVÍTVA: Kivettem a 'pr' (padding-right) értéket, így szimmetrikus lesz a bal oldallal
          boxSizing: 'border-box', 
          width: '100%', 
          maxWidth: '100%', 
          minWidth: 0 
        }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, height: { md: 'calc(100vh - 200px)' }, width: '100%' }}>
            
            {/* Alert Creation */}
            <Box>
              <Card sx={{
                bgcolor: '#1a1d2e',
                borderRadius: 3,
                border: '1px solid #2a2d3d',
                flex: '0 0 auto',
                width: '100%'
              }}>
                <CardContent>
                  <Typography variant="h6" sx={{
                    color: 'white',
                    mb: 2,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1
                  }}>
                    <Notifications sx={{ color: '#ff9800' }} />
                    Create Alert
                  </Typography>
                  <AlertCreationForm onAlertCreated={loadAlerts} />
                </CardContent>
              </Card>
            </Box>

            {/* Tabbed Section */}
            <Box sx={{ flex: 1, minHeight: 0 }}>
              <Card sx={{
                bgcolor: '#1a1d2e',
                borderRadius: 3,
                border: '1px solid #2a2d3d',
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                width: '100%'
              }}>

                <AppBar position="static" sx={{ 
                  bgcolor: '#242742', 
                  borderTopLeftRadius: 12, 
                  borderTopRightRadius: 12,
                  boxShadow: 'none'
                }}>
                  <Tabs
                    value={rightTab}
                    onChange={(e, newValue) => setRightTab(newValue)}
                    indicatorColor="primary"
                    textColor="inherit"
                    variant="fullWidth"
                    sx={{
                      '& .MuiTabs-indicator': { backgroundColor: '#64b5f6' },
                    }}
                  >
                    <Tab label="Alerts" icon={<Notifications />} iconPosition="start" sx={{ textTransform: 'none' }} />
                    <Tab label="Earnings" icon={<Event />} iconPosition="start" sx={{ textTransform: 'none' }} />
                    <Tab label="News" icon={<RssFeed />} iconPosition="start" sx={{ textTransform: 'none' }} />
                  </Tabs>
                </AppBar>

                <Box sx={{
                  flex: 1,
                  overflowY: 'auto',
                  overflowX: 'hidden',
                  minHeight: 0,
                  paddingRight: '12px', // Megtartjuk a "biztonsági" belső paddinget a görgősávnak
                  boxSizing: 'border-box',
                  '&::-webkit-scrollbar': { width: '8px' },
                  '&::-webkit-scrollbar-track': { background: 'transparent' },
                  '&::-webkit-scrollbar-thumb': { background: '#2a2d3d', borderRadius: '4px' },
                  '&::-webkit-scrollbar-thumb:hover': { background: '#64b5f6' },
                }}>
                  
                  {/* FÜL 0: AKTÍV ALERTEK */}
                  {rightTab === 0 && (
                    <Box sx={{ px: 2, pb: 2, pt: 2 }}>
                      <Typography variant="h6" sx={{ color: 'white', mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Notifications sx={{ color: '#ff9800' }} />
                        Active Alerts ({alerts.filter(a => a.isActive).length})
                      </Typography>
                      <List sx={{ p: 0 }}>
                        {alerts.filter(a => a.isActive).map((alert) => (
                          <ListItem 
                            key={alert.id} 
                            sx={{ 
                              pl: 2,
                              pr: 0, 
                              py: 1, 
                              borderRadius: 2, 
                              mb: 1, 
                              bgcolor: '#242742' 
                            }}
                          >
                            <ListItemText
                              disableTypography
                              primary={
                                <Box sx={{ 
                                  display: 'flex', 
                                  justifyContent: 'space-between', 
                                  alignItems: 'center',
                                  pr: 7,
                                  mt: 1 
                                }}>
                                  <Typography variant="body1" sx={{ color: 'white', fontWeight: 500 }}>
                                    {alert.symbol}
                                  </Typography>
                                  
                                  <Chip
                                    label={alert.alertType === 0 ? 'Price Above' : 'Price Below'}
                                    size="small"
                                    sx={{ 
                                      bgcolor: alert.alertType === 0 ? '#4caf50' : '#f44336', 
                                      color: 'white', 
                                      fontWeight: 500,
                                      height: '24px',
                                      position: 'relative',
                                      top: '8px',
                                      right: '5px'
                                    }}
                                  />
                                </Box>
                              }
                              secondary={
                                <Typography variant="body2" sx={{ color: '#9e9e9e', mt: 0.5 }}>
                                  Target: {formatPrice(alert.targetPrice)}
                                </Typography>
                              }
                            />
                            <ListItemSecondaryAction>
                              <IconButton 
                                onClick={() => deleteAlert(alert.id)} 
                                sx={{ 
                                  color: '#f44336', 
                                  '&:hover': { bgcolor: 'rgba(244, 67, 54, 0.1)' },
                                  mr: 1 
                                }}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </ListItemSecondaryAction>
                          </ListItem>
                        ))}
                      </List>
                      {alerts.filter(a => a.isActive).length === 0 && (
                        <Typography variant="body2" sx={{ color: '#9e9e9e', textAlign: 'center', py: 2 }}>No active alerts</Typography>
                      )}
                    </Box>
                  )}

                  {/* FÜL 1: EARNINGS NAPTÁR */}
                  {rightTab === 1 && <EarningsCalendar />}

                  {/* FÜL 2: CÉGHÍREK */}
                  {rightTab === 2 && <CompanyNews selectedSymbol={selectedSymbols[0]} />}
                </Box>
              </Card>
            </Box>
          </Box>
        </Box>
      </Box>      
      
      <Snackbar
        open={notification.open}
        autoHideDuration={4000}
        onClose={handleCloseNotification}
        TransitionComponent={Fade}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity} sx={{ width: '100%' }}>
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default ModernDashboard;