import React, { useState } from 'react';
import {
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button,
  Box,
  Snackbar,
  Alert
} from '@mui/material';
import axios from 'axios';

const TRACKED_SYMBOLS = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'AMZN', 'META', 'NVDA', 'JPM', 'V', 'NFLX'];
const ALERT_TYPES = [
  { value: 0, label: 'Price Above' },
  { value: 1, label: 'Price Below' },
  { value: 2, label: 'Percent Change Above' },
  { value: 3, label: 'Percent Change Below' }
];

const API_URL = 'http://localhost:5055/api/alerts';

function AlertCreationForm({ onAlertCreated }) {
  const [formData, setFormData] = useState({
    symbol: '',
    targetPrice: '',
    alertType: 0,
    userId: 'user1' // Default user ID
  });
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const alertData = {
        symbol: formData.symbol,
        targetPrice: parseFloat(formData.targetPrice),
        alertType: formData.alertType,
        userId: formData.userId
      };

      await axios.post(API_URL, alertData);
      
      setNotification({
        open: true,
        message: 'Alert created successfully!',
        severity: 'success'
      });

      // Reset form
      setFormData({
        symbol: '',
        targetPrice: '',
        alertType: 0,
        userId: 'user1'
      });

      if (onAlertCreated) onAlertCreated();
    } catch (error) {
      setNotification({
        open: true,
        message: 'Error creating alert: ' + (error.response?.data?.message || error.message),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field) => (event) => {
    setFormData(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  return (
    <>
      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' } }}>
        <FormControl sx={{ gridColumn: { xs: '1 / -1', sm: '1 / 2' } }} fullWidth>
          <InputLabel sx={{ color: '#9e9e9e' }}>Stock Symbol</InputLabel>
          <Select
            value={formData.symbol}
            onChange={handleChange('symbol')}
            label="Stock Symbol"
            required
            sx={{
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#2a2d3d'
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#64b5f6'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: '#64b5f6'
              },
              color: 'white'
            }}
          >
            {TRACKED_SYMBOLS.map((symbol) => (
              <MenuItem key={symbol} value={symbol}>
                {symbol}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          label="Target Price/Percentage"
          type="number"
          value={formData.targetPrice}
          onChange={handleChange('targetPrice')}
          required
          inputProps={{ step: '0.01', min: '0' }}
          helperText="Enter price for price alerts, or percentage for change alerts"
          sx={{
            gridColumn: '1 / -1',
            '& .MuiInputLabel-root': {
              color: '#9e9e9e'
            },
            '& .MuiOutlinedInput-root': {
              color: 'white',
              '& fieldset': {
                borderColor: '#2a2d3d'
              },
              '&:hover fieldset': {
                borderColor: '#64b5f6'
              },
              '&.Mui-focused fieldset': {
                borderColor: '#64b5f6'
              }
            },
            '& .MuiFormHelperText-root': {
              color: '#9e9e9e'
            }
          }}
        />

        <FormControl fullWidth sx={{ gridColumn: { xs: '1 / -1', sm: '1 / 2' } }}>
          <InputLabel sx={{ color: '#9e9e9e' }}>Alert Type</InputLabel>
          <Select
            value={formData.alertType}
            onChange={handleChange('alertType')}
            label="Alert Type"
            sx={{
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#2a2d3d'
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#64b5f6'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: '#64b5f6'
              },
              color: 'white'
            }}
          >
            {ALERT_TYPES.map((type) => (
              <MenuItem key={type.value} value={type.value}>
                {type.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Box sx={{ gridColumn: '1 / -1', display: 'flex', justifyContent: 'flex-start' }}>
          <Button 
            type="submit" 
            variant="contained" 
            disabled={loading}
            sx={{ 
              bgcolor: '#64b5f6',
              '&:hover': {
                bgcolor: '#42a5f5'
              },
              '&:disabled': {
                bgcolor: '#2a2d3d'
              }
            }}
          >
            {loading ? 'Creating...' : 'Create Alert'}
          </Button>
        </Box>
      </Box>

      <Snackbar
        open={notification.open}
        autoHideDuration={4000}
        onClose={() => setNotification(prev => ({ ...prev, open: false }))}
      >
        <Alert severity={notification.severity} onClose={() => setNotification(prev => ({ ...prev, open: false }))}>
          {notification.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default AlertCreationForm;