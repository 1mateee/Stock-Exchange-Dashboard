import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Paper, 
  List, 
  ListItem, 
  ListItemText, 
  Chip, 
  Box,
  Grid,
  Button
} from '@mui/material';
import { HubConnectionBuilder } from '@microsoft/signalr';
import StockChart from './StockChart';
import StockSelector from './StockSelector';
import AlertCreationForm from './AlertCreationForm';
// Removed StatsCards widget per request
import axios from 'axios';

const SIGNALR_URL = 'http://localhost:5055/hubs/stock';
const ALERTS_API_URL = 'http://localhost:5055/api/alerts';

function Dashboard() {
  const [stocks, setStocks] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [selectedSymbols, setSelectedSymbols] = useState(['AAPL', 'GOOGL', 'MSFT']); // Default selection

  // Filter stocks based on selection
  const filteredStocks = stocks.filter(stock => selectedSymbols.includes(stock.symbol));

  const loadAlerts = async () => {
    try {
      const response = await axios.get(ALERTS_API_URL);
      setAlerts(response.data);
    } catch (error) {
      console.error('Error loading alerts:', error);
    }
  };

  useEffect(() => {
    const connection = new HubConnectionBuilder()
      .withUrl(SIGNALR_URL)
      .withAutomaticReconnect()
      .build();

    connection.start()
      .then(() => {
        // Join the "all_stocks" group to receive updates
        connection.invoke("JoinAllStocksGroup").catch(console.error);
        
        // Listen for stock updates (correct method name from backend)
        connection.on('StocksUpdated', (data) => {
          setStocks(data);
        });

        // Listen for alert triggers
        connection.on('AlertTriggered', (alert) => {
          const receivedAt = new Date();
          console.log(`Alert triggered for ${alert.symbol} at backend: ${new Date(alert.triggeredAt).toLocaleString()}, received at frontend: ${receivedAt.toLocaleString()}`);
          // Show browser push notification if permission granted
          if ("Notification" in window && Notification.permission === "granted") {
            new Notification(`Alert triggered for ${alert.symbol}!`, {
              body: `Target: ${alert.targetPrice} (${['Price Above','Price Below','Percent Change Above','Percent Change Below'][alert.alertType]})`,
              icon: '/favicon.ico'
            });
          }
          setAlerts((prev) => prev.map(a => a.id === alert.id ? { ...a, isActive: false, triggeredAt: alert.triggeredAt } : a));
        });
      })
      .catch(console.error);

    return () => {
      connection.stop();
    };
  }, []);

  useEffect(() => {
    loadAlerts();
  }, []);

  const handleCreateAlert = async (newAlert) => {
    // Request notification permission if not granted
    if ("Notification" in window && Notification.permission !== "granted") {
      Notification.requestPermission();
    }

    // ...existing alert creation logic (e.g., API call to create alert)...
  };

  return (
  <Box sx={{ mt: 4, maxWidth: 'xl', mx: 'auto', px: 2 }}>
      <Typography variant="h4" gutterBottom align="center">
        Stock Dashboard
      </Typography>

  {/* StatsCards removed */}

  <Grid container spacing={3} wrap="nowrap" sx={{ display: 'flex' }}>
        {/* Left Column - Stock Selection & Live Data */}
  <Grid item xs={12} md={6} sx={{ flex: 1, minWidth: 0 }}>
          <Box sx={{ mb: 2 }}>
            <StockSelector 
              selectedSymbols={selectedSymbols}
              onSymbolsChange={setSelectedSymbols}
            />
          </Box>
          
          <Paper sx={{ p: 2, minHeight: { xs: 'auto', md: '60vh' }, overflow: 'auto' }}>
            <Typography variant="h6" gutterBottom>Live Stocks</Typography>
            <List>
              {filteredStocks.map((stock) => {
                const isPositive = stock.changePercent >= 0;
                return (
                  <ListItem key={stock.symbol} sx={{ display: 'flex', justifyContent: 'space-between', py: 1, borderBottom: '1px solid #f0f0f0' }}>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="h6" sx={{ minWidth: '20%' }}>{stock.symbol}</Typography>
                          <Typography variant="h6" sx={{ color: isPositive ? 'success.main' : 'error.main', fontWeight: 'bold' }}>
                            ${stock.currentPrice?.toFixed(2)}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <React.Fragment>
                          <Typography component="span" variant="body2" color="text.secondary" display="block">
                            {stock.companyName}
                          </Typography>
                          <Typography component="span" variant="caption" color="text.secondary" display="block">
                            Updated: {new Date(stock.lastUpdated).toLocaleTimeString()}
                          </Typography>
                        </React.Fragment>
                      }
                    />
                    <Box sx={{ textAlign: 'right', minWidth: '25%' }}>
                      <Chip 
                        label={`${isPositive ? '+' : ''}${stock.changePercent?.toFixed(2)}%`}
                        color={isPositive ? 'success' : 'error'}
                        variant="filled"
                        size="small"
                        sx={{ mb: 0.5, fontWeight: 'bold' }}
                      />
                      <Typography variant="body2" sx={{ color: isPositive ? 'success.main' : 'error.main', fontWeight: 'bold' }}>
                        ${isPositive ? '+' : ''}{stock.change?.toFixed(2)}
                      </Typography>
                    </Box>
                  </ListItem>
                );
              })}
              {filteredStocks.length === 0 && (
                <Box sx={{ textAlign: 'center', py: 8 }}>
                  <Typography variant="h6" color="text.secondary" gutterBottom>
                    Waiting for stock data...
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    This may take up to 60 seconds.
                  </Typography>
                </Box>
              )}
            </List>
          </Paper>
        </Grid>

  {/* Right Column - Charts & Alerts */}
  <Grid item xs={12} md={6} sx={{ flex: 1, minWidth: 0 }}>
          <Paper sx={{ p: 2, mb: 2, minHeight: { xs: 'auto', md: '40vh' } }}>
            <Typography variant="h6" gutterBottom>Price History</Typography>
            <Box sx={{ height: '90%' }}>
              <StockChart />
            </Box>
          </Paper>
          
          <Paper sx={{ p: 2, mb: 2 }}>
            <AlertCreationForm onAlertCreated={loadAlerts} />
          </Paper>
          
          <Paper sx={{ p: 2, height: '20vh', overflow: 'auto' }}>
            <Typography variant="h6" gutterBottom>Active Alerts</Typography>
            <List dense>
              {alerts.map((alert) => {
                const alertTypeLabels = ['Price Above', 'Price Below', 'Percent Change Above', 'Percent Change Below'];
                return (
                  <ListItem key={alert.id} sx={{ py: 0.5 }}>
                    <ListItemText
                      primary={`${alert.symbol} - ${alertTypeLabels[alert.alertType]} $${alert.targetPrice}`}
                      secondary={
                        alert.isActive 
                          ? `Active since ${new Date(alert.createdAt).toLocaleDateString()}` 
                          : `Triggered at ${new Date(alert.triggeredAt).toLocaleString()}`
                      }
                    />
                    <Chip 
                      label={alert.isActive ? 'Active' : 'Triggered'} 
                      color={alert.isActive ? 'primary' : 'success'}
                      variant="outlined"
                      size="small"
                    />
                  </ListItem>
                );
              })}
              {alerts.length === 0 && (
                <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
                  No alerts created yet.
                </Typography>
              )}
            </List>
          </Paper>
        </Grid>
      </Grid>
  </Box>
  );
}

export default Dashboard;
