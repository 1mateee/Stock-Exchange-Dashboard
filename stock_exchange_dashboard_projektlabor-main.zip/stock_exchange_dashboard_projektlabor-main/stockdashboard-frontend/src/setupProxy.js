const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  // Proxy API requests to backend on port 5055
  app.use(
    '/api',
    createProxyMiddleware({
      // Use the HTTPS backend port to avoid http -> https redirects breaking preflight
  target: 'http://localhost:5055',
      changeOrigin: true,
      secure: false,
      logLevel: 'debug',
      onProxyReq: (proxyReq, req, res) => {
        console.debug('[proxy] api req ->', req.method, req.originalUrl);
      }
    })
  );

  // Proxy SignalR hub negotiate/connect and websocket traffic
  app.use(
    '/hubs',
    createProxyMiddleware({
  target: 'http://localhost:5055',
      ws: true,
      changeOrigin: true,
      secure: false,
      logLevel: 'debug',
      onProxyReqWs: (proxyReq, req, socket, options, head) => {
        console.debug('[proxy] ws req ->', req.method, req.url);
      }
    })
  );
};
