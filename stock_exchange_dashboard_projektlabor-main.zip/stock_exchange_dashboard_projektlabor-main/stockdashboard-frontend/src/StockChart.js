import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Box, ButtonGroup, Button, Chip, Stack } from '@mui/material';
import axios from 'axios';

const CACHE_KEY = (symbol) => `stock_history_${symbol}_30d`;
const CACHE_EXPIRY_MS = 60 * 60 * 1000; // 1 hour

// Helper to pad numbers with leading zeros
const pad = (n) => String(n).padStart(2, '0');

function StockChart({ selectedSymbols = [] }) {
  const [data, setData] = useState([]);
  const [timeframe, setTimeframe] = useState(7); // days
  const [loading, setLoading] = useState(false);

  const loadSingle = async (symbol, days) => {
    setLoading(true);
    try {
      // --- HA 1D (intraday), KÜLÖN ENDPOINT ---
      if (days === 1) {
        let url = `http://localhost:5055/api/stocks/${symbol}/intraday`;
        const response = await axios.get(url);
        const raw = response.data || [];

        console.log(`StockChart 1D (intraday) response for ${symbol}:`, raw);

        // Az 1D adat már formázva jön HH:mm stringben, használjuk közvetlenül
        const formatted = raw.map(item => {
          if (!item || !item.timestamp || item.price === undefined) return null;
          return {
            timestamp: item.timestamp, // Már "HH:mm" formátumban van
            price: item.price ? parseFloat(item.price) : null
          };
        }).filter(x => x !== null);
        
        console.log(`StockChart 1D formatted for ${symbol}:`, formatted);
        return formatted;
      }

      // --- 7D/30D LOGIKA: /history endpoint ---
      let url = `http://localhost:5055/api/stocks/${symbol}/history?days=${days}`;
      const response = await axios.get(url);
      const raw = response.data || [];

      console.log(`StockChart ${days}D response for ${symbol}:`, raw);

      if (days === 30) {
        const cached = localStorage.getItem(CACHE_KEY(symbol));
        if (cached) {
          const { data: cachedData, timestamp } = JSON.parse(cached);
          const hasNonNull = Array.isArray(cachedData) && cachedData.some(p => p?.price != null);
          if (Date.now() - timestamp < CACHE_EXPIRY_MS && hasNonNull) {
            return cachedData;
          }
          if (!hasNonNull) {
            localStorage.removeItem(CACHE_KEY(symbol));
          }
        }
      }

      const mapByDay = new Map();
      raw.forEach(item => {
        if (!item || item.timestamp === undefined) return;
        const d = new Date(item.timestamp * 1000);
        const key = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
        mapByDay.set(key, item);
      });

      const now = new Date();
      const baseUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
      const calendar = [];
      for (let i = days - 1; i >= 0; i--) {
        const dUtc = new Date(baseUtc);
        dUtc.setUTCDate(dUtc.getUTCDate() - i);
        const key = `${dUtc.getUTCFullYear()}-${pad(dUtc.getUTCMonth() + 1)}-${pad(dUtc.getUTCDate())}`;
        const item = mapByDay.get(key);
        calendar.push({
          timestamp: dUtc.toISOString().slice(0, 10), 
          price: item && item.price ? parseFloat(item.price) : null,
          date: item && item.timestamp ? item.timestamp * 1000 : dUtc.getTime()
        });
      }

      // Interpoláció
      const validIndices = calendar.reduce((acc, item, idx) => {
        if (item.price !== null) acc.push(idx);
        return acc;
      }, []);

      for (let i = 0; i < validIndices.length - 1; i++) {
        const startIdx = validIndices[i];
        const endIdx = validIndices[i + 1];
        const startPrice = calendar[startIdx].price;
        const endPrice = calendar[endIdx].price;
        const steps = endIdx - startIdx;
        for (let j = 1; j < steps; j++) {
          const frac = j / steps;
          calendar[startIdx + j].price = startPrice + frac * (endPrice - startPrice);
        }
      }

      if (validIndices.length > 0) {
        const firstPrice = calendar[validIndices[0]].price;
        for (let j = 0; j < validIndices[0]; j++) {
          calendar[j].price = firstPrice;
        }
        const lastPrice = calendar[validIndices[validIndices.length - 1]].price;
        for (let j = validIndices[validIndices.length - 1] + 1; j < calendar.length; j++) {
          calendar[j].price = lastPrice;
        }
      }

      console.log('StockChart 7/30D raw response for', symbol, 'days=', days, raw);
      console.log('StockChart 7/30D generated calendar:', calendar);

      if (days === 30 && calendar.some(p => p.price != null)) {
        localStorage.setItem(CACHE_KEY(symbol), JSON.stringify({ data: calendar, timestamp: Date.now() }));
      }

      return calendar;
    } catch (error) {
      console.error('Error loading chart data:', error);
      return [];
    } finally {
      // loading state handled by outer wrapper
    }
  };

  useEffect(() => {
    let isMounted = true;
    const loadAll = async () => {
      setLoading(true);
      try {
        // --- MÓDOSÍTÁS KEZDETE: API LIMIT KEZELÉSE ---
        let symbolsToLoad = selectedSymbols;
        
        // 1D-nél is az összes szimbólumot töltjük be (Alpha Vantage cache miatt OK)
        console.log(`${timeframe}D nézet: Összes kiválasztott részvény (${symbolsToLoad.join(', ')}) betöltése...`);
        // --- MÓDOSÍTÁS VÉGE ---

        let results = await Promise.all(symbolsToLoad.map(sym => loadSingle(sym, timeframe)));

        const totalNonNullPoints = results.reduce((sum, series) => sum + (series?.filter(p => p.price != null).length || 0), 0);
        if (totalNonNullPoints === 0 && timeframe === 30) {
          results = await Promise.all(symbolsToLoad.map(sym => loadSingle(sym, 7)));
        }

        const allTimestampsSet = new Set();
        results.forEach(series => series.forEach(p => allTimestampsSet.add(p.timestamp)));
        const allTimestamps = Array.from(allTimestampsSet);
        allTimestamps.sort();

        // A 'symbolsToLoad' listát használjuk a 'selectedSymbols' helyett
        const seriesMap = results.map((series, idx) => ({ 
          symbol: symbolsToLoad[idx], 
          series 
        }));
        
        const merged = allTimestamps.map(ts => {
          const row = { timestamp: ts };
          seriesMap.forEach(({ symbol, series }) => {
            const point = series.find(p => p.timestamp === ts);
            row[symbol] = point ? point.price : null;
          });
          return row;
        });

        if (isMounted) setData(merged);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    if (selectedSymbols && selectedSymbols.length > 0) {
      loadAll();
    } else {
      setData([]);
    }
    return () => { isMounted = false; };
  }, [selectedSymbols, timeframe]); // Újrafuttatás, ha a szimbólumok VAGY az időtáv változik

  // --- MÓDOSÍTÁS: Dinamikus chip-ek ---
  const getSymbolsToDisplay = () => {
    // Use the same display logic for 1D as for 7D/30D so multiple series overlay
    return selectedSymbols;
  };
  const symbolsOnChart = getSymbolsToDisplay();

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', gap: 2, mb: 2, alignItems: 'center', justifyContent: 'space-between' }}>
        <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap' }}>
          {/* Csak az aktív szimbólumokat mutatjuk */}
          {symbolsOnChart.map((s, idx) => (
            <Chip key={s} label={s} size="small" sx={{ bgcolor: colorForIndex(idx), color: '#0a0e1a', fontWeight: 700 }} />
          ))}
          {/* In 1D we now show all selected symbols like 7D/30D so no "+n more" badge */}
        </Stack>

        {/* --- MÓDOSÍTOTT GOMB CSOPORT (1D GOMB HOZZÁADVA) --- */}
        <ButtonGroup size="small" variant="outlined">
          <Button 
            variant={timeframe === 1 ? 'contained' : 'outlined'}
            onClick={() => setTimeframe(1)}
            sx={{
              color: timeframe === 1 ? 'white' : '#9e9e9e',
              bgcolor: timeframe === 1 ? '#64b5f6' : 'transparent',
              borderColor: '#2a2d3d',
              '&:hover': {
                bgcolor: timeframe === 1 ? '#42a5f5' : '#2a2d3d',
                borderColor: '#64b5f6'
              }
            }}
          >
            1D
          </Button>
          <Button 
            variant={timeframe === 7 ? 'contained' : 'outlined'}
            onClick={() => setTimeframe(7)}
            sx={{
              color: timeframe === 7 ? 'white' : '#9e9e9e',
              bgcolor: timeframe === 7 ? '#64b5f6' : 'transparent',
              borderColor: '#2a2d3d',
              '&:hover': {
                bgcolor: timeframe === 7 ? '#42a5f5' : '#2a2d3d',
                borderColor: '#64b5f6'
              }
            }}
          >
            7D
          </Button>
          <Button 
            variant={timeframe === 30 ? 'contained' : 'outlined'}
            onClick={() => setTimeframe(30)}
            sx={{
              color: timeframe === 30 ? 'white' : '#9e9e9e',
              bgcolor: timeframe === 30 ? '#64b5f6' : 'transparent',
              borderColor: '#2a2d3d',
              '&:hover': {
                bgcolor: timeframe === 30 ? '#42a5f5' : '#2a2d3d',
                borderColor: '#64b5f6'
              }
            }}
          >
            30D
          </Button>
        </ButtonGroup>
      </Box>
      
      {loading ? (
        <Box sx={{ 
          flex: 1,
          minHeight: 0,
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          color: '#9e9e9e'
        }}>
          Loading chart data...
        </Box>
      ) : (data.length === 0 || data.every(row => symbolsOnChart.every(sym => row[sym] == null))) ? (
        <Box sx={{ 
          flex: 1,
          minHeight: 0,
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          color: '#9e9e9e'
        }}>
          No data available for the selected symbols/timeframe.
        </Box>
      ) : (
        <Box sx={{ width: '100%', flex: 1, minHeight: 0 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2d3d" />
              {/* --- MÓDOSÍTOTT XAXIS --- */}
              <XAxis
                dataKey="timestamp"
                type="category"
                // Ritkítás 30D-nél, 1D/7D-nél nincs
                interval={timeframe === 30 ? 3 : 0} 
                // Formázás: 1D-nél "HH:mm", egyébként "MM-DD"
                tickFormatter={(timestamp) => 
                  timeframe === 1 ? timestamp : timestamp.slice(5, 10)
                }
                tick={{ fontSize: 12, fill: '#9e9e9e' }}
                axisLine={{ stroke: '#2a2d3d' }}
                tickLine={{ stroke: '#2a2d3d' }}
              />
              <YAxis 
                domain={['auto', 'auto']} 
                tick={{ fontSize: 12, fill: '#9e9e9e' }}
                axisLine={{ stroke: '#2a2d3d' }}
                tickLine={{ stroke: '#2a2d3d' }}
              />
              {/* --- MÓDOSÍTOTT TOOLTIP --- */}
              <Tooltip 
                // Formázás: 1D-nél "Idő: HH:mm", egyébként "Dátum: YYYY-MM-DD"
                labelFormatter={(label) => 
                  timeframe === 1 ? `Idő: ${label}` : `Dátum: ${label}`
                }
                formatter={(value, name) => value == null ? ['No data', name] : [`$${value?.toFixed(2)}`, name]}
                contentStyle={{
                  backgroundColor: '#1a1d2e',
                  border: '1px solid #2a2d3d',
                  borderRadius: '8px',
                  color: 'white'
                }}
                labelStyle={{ color: '#9e9e9e' }}
              />
              {/* Csak az aktív szimbólumok vonalait rajzoljuk ki */}
              {symbolsOnChart.map((s, idx) => (
                <Line
                  key={s}
                  type="monotone"
                  dataKey={s}
                  stroke={colorForIndex(idx)}
                  dot={false}
                  connectNulls={true}
                  strokeWidth={3}
                  strokeLinecap="round"
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </Box>
      )}
    </Box>
  );
}

export default StockChart;

// simple deterministic color palette
const PALETTE = ['#64b5f6', '#ff9800', '#4caf50', '#e91e63', '#9c27b0', '#00bcd4', '#ff5722', '#cddc39', '#3f51b5', '#8bc34a'];
function colorForIndex(idx) {
  return PALETTE[idx % PALETTE.length];
}