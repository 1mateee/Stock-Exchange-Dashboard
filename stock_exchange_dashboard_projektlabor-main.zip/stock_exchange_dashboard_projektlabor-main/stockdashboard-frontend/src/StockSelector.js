import React from 'react';
import { 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  Chip, 
  Box, 
  OutlinedInput 
} from '@mui/material';

const TRACKED_SYMBOLS = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'AMZN', 'META', 'NVDA', 'JPM', 'V', 'NFLX'];

function StockSelector({ selectedSymbols, onSymbolsChange }) {
  return (
    <FormControl fullWidth>
      <InputLabel sx={{ color: '#9e9e9e' }}>Select Stocks to Display</InputLabel>
      <Select
        multiple
        value={selectedSymbols}
        onChange={(e) => onSymbolsChange(e.target.value)}
        input={<OutlinedInput label="Select Stocks to Display" />}
        sx={{
          '& .MuiOutlinedInput-notchedOutline': {
            borderColor: '#2a2d3d'
          },
          '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: '#64b5f6'
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: '#64b5f6'
          },
          color: 'white'
        }}
        renderValue={(selected) => (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {selected.map((value) => (
              <Chip 
                key={value} 
                label={value} 
                size="small" 
                sx={{
                  bgcolor: '#64b5f6',
                  color: 'white',
                  '& .MuiChip-deleteIcon': {
                    color: 'white'
                  }
                }}
              />
            ))}
          </Box>
        )}
      >
        {TRACKED_SYMBOLS.map((symbol) => (
          <MenuItem key={symbol} value={symbol}>
            {symbol}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}

export default StockSelector;