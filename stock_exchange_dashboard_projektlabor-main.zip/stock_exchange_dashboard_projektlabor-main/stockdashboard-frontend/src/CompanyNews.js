import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  Link,
  CircularProgress
} from '@mui/material';
import { RssFeed } from '@mui/icons-material';

const API_URL = 'http://localhost:5055/api/stocks';

function CompanyNews({ selectedSymbol }) {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadNews = async () => {
      if (!selectedSymbol) {
        setNews([]);
        return;
      }
      setLoading(true);
      try {
        const response = await axios.get(`${API_URL}/${selectedSymbol}/news`);
        setNews(response.data.slice(0, 10));
      } catch (error) {
        console.error(`Error loading news for ${selectedSymbol}:`, error);
        setNews([]);
      } finally {
        setLoading(false);
      }
    };

    loadNews();
  }, [selectedSymbol]);

  const formatDate = (unixTimestamp) => {
    return new Date(unixTimestamp * 1000).toLocaleString();
  };

  return (
    // JAVÍTÁS 1: A px értékét lecsökkentettem 2-ről 1-re (vagy akár 0.5-re).
    // Ez csökkenti a hézagot a kártya és a görgő/szél között.
    <Box sx={{ px: 1, pb: 2, pt: 2 }}>
      <Typography variant="h6" sx={{
        color: 'white',
        mb: 2,
        display: 'flex',
        alignItems: 'center',
        gap: 1,
        px: 1 // A címsornak adtam egy kis plusz paddingot, hogy igazodjon
      }}>
        <RssFeed sx={{ color: '#64b5f6' }} />
        Company News {selectedSymbol ? `(${selectedSymbol})` : ''}
      </Typography>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
          <CircularProgress sx={{ color: '#64b5f6' }} />
        </Box>
      ) : !selectedSymbol ? (
        <Typography variant="body2" sx={{ color: '#9e9e9e', textAlign: 'center', py: 2 }}>
          Select a stock to see news.
        </Typography>
      ) : news.length === 0 ? (
        <Typography variant="body2" sx={{ color: '#9e9e9e', textAlign: 'center', py: 2 }}>
          No recent news found for {selectedSymbol}.
        </Typography>
      ) : (
        <List sx={{ p: 0 }}>
          {news.map((item) => (
            <ListItem
              key={item.id}
              sx={{
                // JAVÍTÁS 2: A px értékét 0-ról 2-re növeltem.
                // Ez tolja befelé a szöveget (Yahoo) és a dátumot a sötétkék doboz szélétől.
                px: 2, 
                py: 1.5, // Kicsit növeltem a függőleges helyet is a szebb megjelenésért
                borderRadius: 2,
                mb: 1,
                bgcolor: '#242742'
              }}
              component={Link}
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              button
            >
              <ListItemText
                disableTypography
                primary={
                  <Typography variant="body2" sx={{ color: 'white', fontWeight: 500, mb: 0.5 }}>
                    {item.headline}
                  </Typography>
                }
                secondary={
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="caption" sx={{ color: '#ff9800', fontWeight: 600 }}>
                      {item.source}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
                      {formatDate(item.datetime)}
                    </Typography>
                  </Box>
                }
              />
            </ListItem>
          ))}
        </List>
      )}
    </Box>
  );
}

export default CompanyNews;