import React from 'react';
import './App.css'; // <--- EZ A SOR HIÁNYZIK! Emiatt nem vékony a görgősáv.
import ModernDashboard from './ModernDashboard';
import { Box } from '@mui/material';

function App() {
  return (
    <Box sx={{ width: '100%', height: '100vh', overflow: 'hidden' }}>
      <ModernDashboard />
    </Box>
  );
}

export default App;