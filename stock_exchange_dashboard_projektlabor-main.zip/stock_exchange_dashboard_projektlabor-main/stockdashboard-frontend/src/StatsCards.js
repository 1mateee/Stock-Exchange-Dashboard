import React from 'react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  Grid
} from '@mui/material';
import { 
  TrendingUp, 
  TrendingDown, 
  Assessment,
  MonetizationOn
} from '@mui/icons-material';

function StatsCards({ stocks }) {
  // Calculate stats
  const totalValue = stocks.reduce((sum, stock) => sum + stock.currentPrice, 0);
  const totalChange = stocks.reduce((sum, stock) => sum + stock.change, 0);
  const positiveStocks = stocks.filter(stock => stock.change >= 0).length;
  const averageChangePercent = stocks.length > 0 
    ? stocks.reduce((sum, stock) => sum + stock.changePercent, 0) / stocks.length 
    : 0;

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  // Determine the stock with the largest percent increase
  const bestStock = stocks.length > 0 ? stocks.reduce((best, s) => {
    if (!best) return s;
    return (s.changePercent || 0) > (best.changePercent || 0) ? s : best;
  }, null) : null;

  const stats = [
    {
      title: 'Legnagyobb növekedés',
      value: bestStock && (bestStock.changePercent > 0)
        ? `${bestStock.symbol} ${bestStock.changePercent >= 0 ? '+' : ''}${bestStock.changePercent.toFixed(2)}%`
        : 'Nincs pozitív növekedés',
      subtitle: bestStock && (bestStock.changePercent > 0)
        ? `${bestStock.change >= 0 ? '+' : ''}$${bestStock.change.toFixed(2)}`
        : `${stocks.length} stocks`,
      icon: <MonetizationOn />,
      color: bestStock && bestStock.change >= 0 ? '#4caf50' : '#64b5f6'
    },
    {
      title: 'Total Change',
      value: `${totalChange >= 0 ? '+' : ''}${totalChange.toFixed(2)}`,
      subtitle: `${totalChange >= 0 ? '+' : ''}${averageChangePercent.toFixed(2)}% avg`,
      icon: totalChange >= 0 ? <TrendingUp /> : <TrendingDown />,
      color: totalChange >= 0 ? '#4caf50' : '#f44336'
    },
    {
      title: 'Performance',
      value: `${positiveStocks}/${stocks.length}`,
      subtitle: 'stocks gaining',
      icon: <Assessment />,
      color: positiveStocks > stocks.length / 2 ? '#4caf50' : '#ff9800'
    }
  ];

  return (
    <Grid container spacing={2}>
      {stats.map((stat, index) => (
        <Grid item xs={12} key={index}>
          <Card sx={{ 
            bgcolor: '#1a1d2e', 
            borderRadius: 3,
            border: '1px solid #2a2d3d',
            position: 'relative',
            overflow: 'hidden',
            '&:hover': {
              transform: 'translateY(-2px)',
              transition: 'transform 0.2s ease-in-out'
            }
          }}>
            <CardContent sx={{ p: 2.5 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="body2" sx={{ color: '#9e9e9e', mb: 0.5 }}>
                    {stat.title}
                  </Typography>
                  <Typography variant="h5" sx={{ 
                    color: 'white', 
                    fontWeight: 700,
                    mb: 0.5
                  }}>
                    {stat.value}
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#9e9e9e' }}>
                    {stat.subtitle}
                  </Typography>
                </Box>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 48,
                  height: 48,
                  borderRadius: '50%',
                  bgcolor: `${stat.color}20`,
                  color: stat.color
                }}>
                  {stat.icon}
                </Box>
              </Box>
              
              {/* Subtle gradient overlay */}
              <Box sx={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '50%',
                height: '100%',
                background: `linear-gradient(45deg, transparent 0%, ${stat.color}05 100%)`,
                pointerEvents: 'none'
              }} />
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}

export default StatsCards;