using Microsoft.EntityFrameworkCore;
using StockDashboard.Api.Data;
using StockDashboard.Api.Hubs;
using StockDashboard.Api.Services;

namespace StockDashboard.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container
            builder.Services.AddControllers();

            // Entity Framework with SQLite
            builder.Services.AddDbContext<StockDbContext>(options =>
                options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")
                    ?? "Data Source=stockdashboard.db"));

            // SignalR
            builder.Services.AddSignalR();

            // Custom services - m�dos�tott regisztr�ci�
            builder.Services.AddScoped<IStockDataService>(sp =>
                new StockDataService(
                    sp.GetRequiredService<HttpClient>(),
                    sp.GetRequiredService<ILogger<StockDataService>>(),
                    builder.Configuration,
                    sp.GetRequiredService<StockDbContext>()
                ));
            builder.Services.AddHostedService<StockUpdateService>();

            // CORS for frontend connection
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    policy =>
                    {
                        policy
                            .WithOrigins("http://localhost:3000")
                            .AllowAnyMethod()
                            .AllowAnyHeader()
                            .AllowCredentials();
                    });
            });

            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            builder.Services.AddHttpClient();

            var app = builder.Build();

            // Configure the HTTP request pipeline
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.UseDeveloperExceptionPage();
            }

            // Create database if it doesn't exist
            using (var scope = app.Services.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<StockDbContext>();
                context.Database.EnsureCreated();
            }

            // Disable HTTPS redirection for local development to avoid self-signed cert issues
            // If you prefer HTTPS locally, revert this change and ensure the dev cert is trusted.
            // app.UseHttpsRedirection();
            app.UseCors("AllowAll");

            app.UseRouting();

            app.MapControllers();
            app.MapHub<StockHub>("/hubs/stock");

            // Test endpoint
            app.MapGet("/", () => "Stock Dashboard API is running!");

            app.Run();
        }
    }
}