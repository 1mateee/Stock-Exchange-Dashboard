using Microsoft.EntityFrameworkCore;
using StockDashboard.Api.Models;

namespace StockDashboard.Api.Data
{
    public class StockDbContext : DbContext
    {
        public StockDbContext(DbContextOptions<StockDbContext> options) : base(options)
        {
        }

        public DbSet<Stock> Stocks { get; set; }
        public DbSet<StockAlert> StockAlerts { get; set; }
        public DbSet<StockHistory> StockHistory { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Stock
            modelBuilder.Entity<Stock>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.HasIndex(e => e.Symbol).IsUnique();
                entity.Property(e => e.Symbol).HasMaxLength(10).IsRequired();
                entity.Property(e => e.CompanyName).HasMaxLength(200).IsRequired();
                entity.Property(e => e.CurrentPrice).HasPrecision(18, 4);
                entity.Property(e => e.PreviousClosePrice).HasPrecision(18, 4);
                entity.Property(e => e.Change).HasPrecision(18, 4);
                entity.Property(e => e.ChangePercent).HasPrecision(18, 4);
            });

            // StockAlert
            modelBuilder.Entity<StockAlert>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Symbol).HasMaxLength(10).IsRequired();
                entity.Property(e => e.TargetPrice).HasPrecision(18, 4);
                entity.Property(e => e.UserId).HasMaxLength(100);
                entity.Property(e => e.Message).HasMaxLength(500);
            });

            // StockHistory
            modelBuilder.Entity<StockHistory>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Symbol).HasMaxLength(10).IsRequired();
                entity.Property(e => e.Price).HasPrecision(18, 4);
                entity.HasIndex(e => new { e.Symbol, e.Timestamp });
            });
        }
    }
}
