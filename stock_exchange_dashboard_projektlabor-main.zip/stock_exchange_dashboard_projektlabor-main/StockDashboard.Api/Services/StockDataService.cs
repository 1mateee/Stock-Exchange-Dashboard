﻿using System.Net;
using System.Collections.Concurrent;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization; // Szükséges a [JsonPropertyName]-hez
using Microsoft.Extensions.Configuration;
using StockDashboard.Api.Models;
using StockDashboard.Api.Data;

namespace StockDashboard.Api.Services
{
    public enum StockApiProvider
    {
        Finnhub,
        Eodhd
    }

    // DTO for Finnhub Company News
    public class FinnhubNews
    {
        public string Category { get; set; } = string.Empty;
        public long Datetime { get; set; }
        public string Headline { get; set; } = string.Empty;
        public int Id { get; set; }
        public string Image { get; set; } = string.Empty;
        public string Related { get; set; } = string.Empty;
        public string Source { get; set; } = string.Empty;
        public string Summary { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
    }

    // DTO for Finnhub Earnings Calendar
    public class FinnhubEarningsResponse
    {
        public List<FinnhubEarning> EarningsCalendar { get; set; } = new();
    }

    public class FinnhubEarning
    {
        public DateTime Date { get; set; }
        public decimal? EpsActual { get; set; }
        public decimal? EpsEstimate { get; set; }
        public string Hour { get; set; } = string.Empty;
        public decimal? RevenueActual { get; set; }
        public decimal? RevenueEstimate { get; set; }
        public string Symbol { get; set; } = string.Empty;
        public int Year { get; set; }
        public int Quarter { get; set; }
    }

    public interface IStockDataService
    {
        Task<Stock?> GetStockDataAsync(string symbol, StockApiProvider provider = StockApiProvider.Finnhub);
        Task<List<Stock>> GetMultipleStockDataAsync(List<string> symbols, StockApiProvider provider = StockApiProvider.Finnhub);
        Task<List<StockHistory>> GetHistoricalDataAsync(string symbol, DateTime from, DateTime to, StockApiProvider provider);
        Task<List<StockHistory>> GetIntradayDataAsync(string symbol, StockApiProvider provider = StockApiProvider.Finnhub);
        Task<List<FinnhubNews>> GetCompanyNewsAsync(string symbol);
        Task<List<FinnhubEarning>> GetEarningsCalendarAsync(DateTime from, DateTime to);
        Task<List<StockDashboard.Api.Models.SearchSuggestion>> SearchSymbolsAsync(string query);
    }


    public class StockDataService : IStockDataService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<StockDataService> _logger;
        private readonly IConfiguration _configuration;
        private readonly StockDbContext _dbContext;
        private readonly JsonSerializerOptions _jsonOptions;

        // A cache kulcsfontosságú a Polygon 5 hívás/perc limitje miatt
        private static readonly ConcurrentDictionary<string, (DateTime ts, List<StockHistory> data)> _intradayCache = new();
        private const int INTRADAY_CACHE_SECONDS = 300; // 5 perc

        public StockDataService(HttpClient httpClient, ILogger<StockDataService> logger, IConfiguration configuration, StockDbContext dbContext)
        {
            _httpClient = httpClient;
            _logger = logger;
            _configuration = configuration;
            _dbContext = dbContext;
            _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        }

        public async Task<Stock?> GetStockDataAsync(string symbol, StockApiProvider provider = StockApiProvider.Finnhub)
        {
            try
            {
                Stock? stock = provider switch
                {
                    StockApiProvider.Finnhub => await GetFinnhubDataAsync(symbol),
                    StockApiProvider.Eodhd => await GetEodhdDataAsync(symbol),
                    _ => null
                };

                if (stock != null)
                {
                    _logger.LogInformation("Successfully fetched data for {Symbol} via {Provider}", symbol, provider);
                    return stock;
                }

                _logger.LogWarning("No data available for {Symbol} via {Provider}", symbol, provider);
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching stock data for symbol {Symbol} via {Provider}", symbol, provider);
                return null;
            }
        }

        public async Task<List<Stock>> GetMultipleStockDataAsync(List<string> symbols, StockApiProvider provider = StockApiProvider.Finnhub)
        {
            var stocks = new List<Stock>();

            foreach (var symbol in symbols)
            {
                var stock = await GetStockDataAsync(symbol, provider);
                if (stock != null)
                {
                    stocks.Add(stock);
                }
            }

            return stocks;
        }

        private async Task<Stock?> GetFinnhubDataAsync(string symbol)
        {
            try
            {
                var apiKey = _configuration["FinnhubApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                    throw new Exception("Finnhub API key not configured");

                var quoteUrl = $"https://finnhub.io/api/v1/quote?symbol={symbol.ToUpper()}&token={apiKey}";
                var quoteResponse = await _httpClient.GetStringAsync(quoteUrl);
                var quoteDoc = JsonDocument.Parse(quoteResponse).RootElement;

                var currentPrice = quoteDoc.GetProperty("c").GetDecimal();
                var previousClose = quoteDoc.GetProperty("pc").GetDecimal();
                var change = quoteDoc.GetProperty("d").GetDecimal();
                var changePercent = quoteDoc.GetProperty("dp").GetDecimal();

                var profileUrl = $"https://finnhub.io/api/v1/stock/profile2?symbol={symbol.ToUpper()}&token={apiKey}";
                var profileResponse = await _httpClient.GetStringAsync(profileUrl);
                var profileDoc = JsonDocument.Parse(profileResponse).RootElement;
                var companyName = profileDoc.GetProperty("name").GetString() ?? $"{symbol} Corp";

                return new Stock
                {
                    Symbol = symbol.ToUpper(),
                    CompanyName = companyName,
                    CurrentPrice = Math.Round(currentPrice, 2),
                    PreviousClosePrice = Math.Round(previousClose, 2),
                    Change = Math.Round(change, 2),
                    ChangePercent = Math.Round(changePercent, 2),
                    Volume = 0,
                    LastUpdated = DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing Finnhub data for {Symbol}", symbol);
                return null;
            }
        }

        private async Task<Stock?> GetEodhdDataAsync(string symbol)
        {
            try
            {
                var apiKey = _configuration["EodhdApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                    throw new Exception("EODHD API key not configured");

                var url = $"https://eodhistoricaldata.com/api/real-time/{symbol}.US?api_token={apiKey}&fmt=json";
                var response = await _httpClient.GetStringAsync(url);
                var root = JsonDocument.Parse(response).RootElement;

                return new Stock
                {
                    Symbol = symbol.ToUpper(),
                    CompanyName = root.GetProperty("name").GetString() ?? $"{symbol} Corp",
                    CurrentPrice = root.GetProperty("last").GetDecimal(),
                    PreviousClosePrice = root.GetProperty("prev_close").GetDecimal(),
                    Change = root.GetProperty("change").GetDecimal(),
                    ChangePercent = root.GetProperty("change_pct").GetDecimal(),
                    Volume = root.GetProperty("volume").GetInt64(),
                    LastUpdated = DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing EODHD data for {Symbol}", symbol);
                return null;
            }
        }
        public async Task<List<StockHistory>> GetHistoricalDataAsync(
            string symbol,
            DateTime from,
            DateTime to,
            StockApiProvider provider = StockApiProvider.Eodhd)
        {
            try
            {
                var cached = _dbContext.StockHistory
                    .Where(h => h.Symbol == symbol.ToUpper() && h.Timestamp >= from && h.Timestamp <= to)
                    .OrderBy(h => h.Timestamp)
                    .ToList();

                var expectedDates = new HashSet<DateTime>();
                for (var date = from.Date; date <= to.Date; date = date.AddDays(1))
                {
                    if (date.DayOfWeek >= DayOfWeek.Monday && date.DayOfWeek <= DayOfWeek.Friday)
                    {
                        expectedDates.Add(date);
                    }
                }

                var cachedDates = new HashSet<DateTime>(cached.Select(h => h.Timestamp.Date));
                var missingDates = expectedDates.Except(cachedDates).ToList();

                if (missingDates.Count > 0)
                {
                    _logger.LogInformation("Missing {Count} dates for {Symbol}, fetching from API", missingDates.Count, symbol);
                    
                    if (provider != StockApiProvider.Eodhd)
                        throw new NotSupportedException("Historical data currently only supported via EODHD");

                    var apiKey = _configuration["EodhdApiKey"];
                    if (string.IsNullOrEmpty(apiKey))
                        throw new Exception("EODHD API key not configured");
                    
                    var apiFromStr = from.AddDays(-7).ToString("yyyy-MM-dd"); 
                    var apiToStr = DateTime.UtcNow.ToString("yyyy-MM-dd"); 

                    var url = $"https://eodhistoricaldata.com/api/eod/{symbol}.US?from={apiFromStr}&to={apiToStr}&api_token={apiKey}&fmt=json";
                    
                    _logger.LogInformation("Fetching historical data from API: {Url}", url);
                    
                    var httpResponse = await _httpClient.GetAsync(url);
                    if (!httpResponse.IsSuccessStatusCode)
                    {
                        _logger.LogWarning("EODHD historical request failed for {Symbol} with status {Status}", symbol, httpResponse.StatusCode);

                        if (cached.Count > 0)
                        {
                            _logger.LogInformation("Returning {Count} cached records for {Symbol} due to EODHD failure", cached.Count, symbol);
                            return cached;
                        }
                        
                        try
                        {
                            var intraday = await GetIntradayDataAsync(symbol);
                            if (intraday.Count > 0)
                            {
                                _logger.LogInformation("Falling back to intraday data with {Count} points for {Symbol}", intraday.Count, symbol);

                                var latestByDay = intraday
                                    .GroupBy(h => h.Timestamp.Date)
                                    .Select(g => g.OrderByDescending(x => x.Timestamp).First())
                                    .ToList();

                                foreach (var h in latestByDay)
                                {
                                    if (!_dbContext.StockHistory.Any(x => x.Symbol == h.Symbol && x.Timestamp.Date == h.Timestamp.Date))
                                    {
                                        _dbContext.StockHistory.Add(h);
                                    }
                                }
                                await _dbContext.SaveChangesAsync();
                                
                                cached = _dbContext.StockHistory
                                    .Where(h => h.Symbol == symbol.ToUpper() && h.Timestamp >= from && h.Timestamp <= to)
                                    .OrderBy(h => h.Timestamp)
                                    .ToList();

                                return cached;
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Intraday fallback failed for {Symbol}", symbol);
                        }

                        _logger.LogWarning("No historical data available for {Symbol} after fallbacks", symbol);
                        return cached; // empty
                    }

                    var response = await httpResponse.Content.ReadAsStringAsync();

                    var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                    var data = JsonSerializer.Deserialize<List<EodhdHistorical>>(response, options);

                    _logger.LogInformation("API returned {Count} historical records for {Symbol}", data?.Count ?? 0, symbol);

                    var newHistory = data?.Select(d => new StockHistory
                    {
                        Symbol = symbol.ToUpper(),
                        Price = d.Close,
                        Volume = d.Volume,
                        Timestamp = d.Date
                    }).ToList() ?? new List<StockHistory>();

                    _logger.LogInformation("Processing {Count} new historical records", newHistory.Count);
                    
                    int addedCount = 0;
                    foreach (var h in newHistory)
                    {
                        if (!_dbContext.StockHistory.Any(x => x.Symbol == h.Symbol && x.Timestamp.Date == h.Timestamp.Date))
                        {
                            _dbContext.StockHistory.Add(h);
                            addedCount++;
                        }
                    }
                    
                    if (addedCount > 0)
                    {
                        await _dbContext.SaveChangesAsync();
                        _logger.LogInformation("Added {Count} new historical records to database", addedCount);
                    }
                    
                    cached = _dbContext.StockHistory
                        .Where(h => h.Symbol == symbol.ToUpper() && h.Timestamp >= from && h.Timestamp <= to)
                        .OrderBy(h => h.Timestamp)
                        .ToList();
                }

                return cached;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching historical data for {Symbol}", symbol);
                return new List<StockHistory>();
            }
        }

        // *** MÓDOSÍTOTT METÓDUS ***
        public async Task<List<StockHistory>> GetIntradayDataAsync(string symbol, StockApiProvider provider = StockApiProvider.Finnhub)
        {
            try
            {
                // Serve from short cache if available
                if (_intradayCache.TryGetValue(symbol.ToUpper(), out var cached) && (DateTime.UtcNow - cached.ts).TotalSeconds < INTRADAY_CACHE_SECONDS)
                {
                    _logger.LogInformation("Serving intraday data for {Symbol} from cache", symbol);
                    return cached.data;
                }

                _logger.LogInformation("Fetching intraday data from Alpha Vantage for {Symbol}", symbol);
                var apiKey = _configuration["AlphaVantageApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                    throw new Exception("Alpha Vantage API key not configured");

                // Alpha Vantage TIME_SERIES_INTRADAY endpoint (60 minute interval)
                // Use `compact` outputsize on free tier. `full` is a premium feature and returns an informational message when not allowed.
                var outputSize = "compact";
                var url = $"https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol.ToUpper()}&interval=60min&apikey={apiKey}&outputsize={outputSize}";
                _logger.LogInformation("Fetching intraday data from Alpha Vantage (outputsize={OutputSize}): {Url}", outputSize, url);

                var httpResponse = await _httpClient.GetAsync(url);
                if (!httpResponse.IsSuccessStatusCode)
                {
                    _logger.LogWarning("Alpha Vantage intraday request failed for {Symbol} with status {Status}", symbol, httpResponse.StatusCode);
                    return new List<StockHistory>();
                }
                
                var response = await httpResponse.Content.ReadAsStringAsync();
                
                // Check for API error message in response and retry a few times if it's an informational/rate-limit note
                int maxRetries = 2;
                int attempt = 0;
                int[] backoffMs = new[] { 5000, 10000 };
                while (true)
                {
                    if (response.Contains("\"Error Message\"") || response.Contains("\"Note\"") || response.Contains("\"Information\""))
                    {
                        _logger.LogWarning("Alpha Vantage API informational response for {Symbol}: {ResponseSnippet}", symbol, response.Length > 200 ? response.Substring(0, 200) + "..." : response);
                        if (attempt < maxRetries)
                        {
                            var delay = backoffMs[Math.Min(attempt, backoffMs.Length - 1)];
                            _logger.LogInformation("Retrying Alpha Vantage request for {Symbol} after {Delay}ms (attempt {Attempt})", symbol, delay, attempt + 1);
                            await Task.Delay(delay);
                            httpResponse = await _httpClient.GetAsync(url);
                            if (!httpResponse.IsSuccessStatusCode)
                            {
                                _logger.LogWarning("Alpha Vantage intraday request failed for {Symbol} with status {Status} on retry", symbol, httpResponse.StatusCode);
                                break;
                            }
                            response = await httpResponse.Content.ReadAsStringAsync();
                            attempt++;
                            continue; // re-evaluate the new response
                        }
                        else
                        {
                            _logger.LogWarning("Alpha Vantage informational response persisted for {Symbol} after {Attempts} attempts", symbol, attempt + 1);
                            break;
                        }
                    }
                    break;
                }

                var data = JsonSerializer.Deserialize<AlphaVantageResponse>(response, _jsonOptions);

                if (data?.TimeSeries != null && data.TimeSeries.Count > 0)
                {
                    var result = new List<StockHistory>();
                    
                    foreach(var kvp in data.TimeSeries)
                    {
                        if (DateTime.TryParseExact(kvp.Key, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var timestamp))
                        {
                            var timeSeriesData = kvp.Value;
                            if (decimal.TryParse(timeSeriesData.Close, CultureInfo.InvariantCulture, out var closePrice) &&
                                long.TryParse(timeSeriesData.Volume, CultureInfo.InvariantCulture, out var volume))
                            {
                                result.Add(new StockHistory
                                {
                                    Symbol = symbol.ToUpper(),
                                    Price = closePrice,
                                    Volume = volume,
                                    Timestamp = timestamp
                                });
                            }
                        }
                    }
                    
                    result = result.OrderBy(h => h.Timestamp).ToList();
                    _intradayCache[symbol.ToUpper()] = (DateTime.UtcNow, result);
                    _logger.LogInformation("Retrieved {Count} intraday data points from Alpha Vantage for {Symbol}", result.Count, symbol);
                    return result;
                }

                // Log more diagnostics when Alpha Vantage returns no time series
                try
                {
                    using var doc = JsonDocument.Parse(response);
                    var root = doc.RootElement;
                    var propNames = root.EnumerateObject().Select(p => p.Name).ToList();
                    _logger.LogWarning("Alpha Vantage returned no intraday data for {Symbol}. Top-level keys: {Keys}", symbol, string.Join(",", propNames));
                    // Also log the full response at DEBUG level so we don't clutter INFO logs
                    _logger.LogDebug("Alpha Vantage raw response for {Symbol}: {Response}", symbol, response);
                }
                catch (Exception parseEx)
                {
                    _logger.LogWarning(parseEx, "Alpha Vantage response for {Symbol} could not be parsed as JSON", symbol);
                    _logger.LogDebug("Alpha Vantage raw response for {Symbol}: {Response}", symbol, response);
                }

                // Try a fallback to Finnhub candles if Alpha Vantage has no usable data
                try
                {
                    var fhKey = _configuration["FinnhubApiKey"];
                    if (!string.IsNullOrEmpty(fhKey))
                    {
                        _logger.LogInformation("Attempting Finnhub fallback for {Symbol}", symbol);
                        var to = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                        var from = DateTimeOffset.UtcNow.AddDays(-7).ToUnixTimeSeconds();
                        var fhUrl = $"https://finnhub.io/api/v1/stock/candle?symbol={symbol.ToUpper()}&resolution=60&from={from}&to={to}&token={fhKey}";
                        _logger.LogInformation("Fetching candles from Finnhub: {Url}", fhUrl);
                        var fhResponseMsg = await _httpClient.GetAsync(fhUrl);
                        var fhContent = await fhResponseMsg.Content.ReadAsStringAsync();
                        if (!fhResponseMsg.IsSuccessStatusCode)
                        {
                            _logger.LogWarning("Finnhub fallback failed for {Symbol} with status {Status}. Body: {Body}", symbol, fhResponseMsg.StatusCode, fhContent.Length > 500 ? fhContent.Substring(0, 500) + "..." : fhContent);
                        }
                        else
                        {
                            var fhData = JsonSerializer.Deserialize<FinnhubCandleData>(fhContent, _jsonOptions);

                            if (fhData != null && fhData.S != null && fhData.S.Equals("ok", StringComparison.OrdinalIgnoreCase) && fhData.C != null && fhData.T != null)
                            {
                                var list = new List<StockHistory>();
                                for (int i = 0; i < fhData.C.Length; i++)
                                {
                                    var ts = DateTimeOffset.FromUnixTimeSeconds(fhData.T[i]).UtcDateTime;
                                    var vol = (fhData.V != null && i < fhData.V.Length) ? fhData.V[i] : 0L;
                                    list.Add(new StockHistory
                                    {
                                        Symbol = symbol.ToUpper(),
                                        Price = fhData.C[i],
                                        Volume = vol,
                                        Timestamp = ts
                                    });
                                }

                                list = list.OrderBy(h => h.Timestamp).ToList();
                                _intradayCache[symbol.ToUpper()] = (DateTime.UtcNow, list);
                                _logger.LogInformation("Retrieved {Count} intraday points from Finnhub for {Symbol}", list.Count, symbol);
                                return list;
                            }
                            else
                            {
                                _logger.LogWarning("Finnhub fallback returned no usable data for {Symbol} (status={Status})", symbol, fhData?.S);
                            }
                        }
                    }
                    else
                    {
                        _logger.LogWarning("FinnhubApiKey not configured; cannot attempt Finnhub fallback for {Symbol}", symbol);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Finnhub fallback failed for {Symbol}", symbol);
                }

                return new List<StockHistory>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching intraday data for {Symbol} from Alpha Vantage", symbol);
                return new List<StockHistory>();
            }
        }

        // Segédfüggvény az utolsó kereskedési nap megtalálásához
        private DateTime GetMostRecentTradingDay(DateTime utcNow)
        {
            var date = utcNow;
            
            // Ha a piac még nem nyitott ki (feltételezve, hogy 14:30 UTC-kor nyit, ami 9:30 New York-i idő)
            // VAGY ha hétvége van, akkor az előző napot nézzük.
            if (utcNow.TimeOfDay < TimeSpan.FromHours(14.5) || 
                utcNow.DayOfWeek == DayOfWeek.Saturday || 
                utcNow.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(-1);
            }

            // Visszamegyünk, amíg hétköznapot nem találunk
            while (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(-1);
            }

            return date.Date;
        }

        public async Task<List<StockDashboard.Api.Models.SearchSuggestion>> SearchSymbolsAsync(string query)
        {
            // ... (Ez a metódus változatlan marad) ...
            var suggestions = new List<StockDashboard.Api.Models.SearchSuggestion>();
            try
            {
                var apiKey = _configuration["FinnhubApiKey"];
                if (string.IsNullOrWhiteSpace(apiKey))
                {
                    _logger.LogWarning("FinnhubApiKey not configured; external search unavailable");
                    return suggestions;
                }

                var url = $"https://finnhub.io/api/v1/search?q={Uri.EscapeDataString(query)}&token={apiKey}";
                var resp = await _httpClient.GetAsync(url);
                if (!resp.IsSuccessStatusCode)
                {
                    _logger.LogWarning("Finnhub search failed with status {Status}", resp.StatusCode);
                    return suggestions;
                }

                var json = await resp.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                if (!doc.RootElement.TryGetProperty("result", out var arr) || arr.ValueKind != JsonValueKind.Array)
                    return suggestions;

                foreach (var item in arr.EnumerateArray())
                {
                    var symbol = item.TryGetProperty("symbol", out var s) ? s.GetString() : null;
                    var desc = item.TryGetProperty("description", out var d) ? d.GetString() : null;
                    if (string.IsNullOrWhiteSpace(symbol)) continue;
                    suggestions.Add(new StockDashboard.Api.Models.SearchSuggestion
                    {
                        Symbol = symbol!.ToUpperInvariant(),
                        CompanyName = desc ?? string.Empty,
                        Description = desc
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "External symbol search failed for query '{Query}'", query);
            }

            return suggestions;
        }

        public async Task<List<FinnhubNews>> GetCompanyNewsAsync(string symbol)
        {
            // ... (Ez a metódus változatlan marad) ...
            try
            {
                var apiKey = _configuration["FinnhubApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                    throw new Exception("Finnhub API key not configured");

                var fromDate = DateTime.UtcNow.AddDays(-7).ToString("yyyy-MM-dd");
                var toDate = DateTime.UtcNow.ToString("yyyy-MM-dd");

                var url = $"https://finnhub.io/api/v1/company-news?symbol={symbol.ToUpper()}&from={fromDate}&to={toDate}&token={apiKey}";
                _logger.LogInformation("Fetching company news from Finnhub: {Url}", url);

                var response = await _httpClient.GetStringAsync(url);
                var news = JsonSerializer.Deserialize<List<FinnhubNews>>(response, _jsonOptions);

                return news ?? new List<FinnhubNews>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching company news for {Symbol} from Finnhub", symbol);
                return new List<FinnhubNews>();
            }
        }

        public async Task<List<FinnhubEarning>> GetEarningsCalendarAsync(DateTime from, DateTime to)
        {
            // ... (Ez a metódus változatlan marad) ...
            try
            {
                var apiKey = _configuration["FinnhubApiKey"];
                if (string.IsNullOrEmpty(apiKey))
                    throw new Exception("Finnhub API key not configured");
                
                var fromDate = from.ToString("yyyy-MM-dd");
                var toDate = to.ToString("yyyy-MM-dd");

                var url = $"https://finnhub.io/api/v1/calendar/earnings?from={fromDate}&to={toDate}&token={apiKey}";
                _logger.LogInformation("Fetching earnings calendar from Finnhub: {Url}", url);

                var response = await _httpClient.GetStringAsync(url);
                var data = JsonSerializer.Deserialize<FinnhubEarningsResponse>(response, _jsonOptions);

                return data?.EarningsCalendar ?? new List<FinnhubEarning>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching earnings calendar from Finnhub");
                return new List<FinnhubEarning>();
            }
        }

        // --- DTO OSZTÁLYOK ---

        // EODHD
        public class EodhdHistorical
        {
            public DateTime Date { get; set; }
            public decimal Open { get; set; }
            public decimal High { get; set; }
            public decimal Low { get; set; }
            public decimal Close { get; set; }
            public long Volume { get; set; }
        }

        // Finnhub
        public class FinnhubCandleData
        {
            public decimal[]? C { get; set; }
            public decimal[]? H { get; set; }
            public decimal[]? L { get; set; }
            public decimal[]? O { get; set; }
            public string? S { get; set; }
            public long[]? T { get; set; }
            public long[]? V { get; set; }
        }
        
        // Polygon.io
        public class PolygonAggsResponse
        {
            [JsonPropertyName("results")]
            public List<PolygonAgg>? Results { get; set; }
            [JsonPropertyName("status")]
            public string? Status { get; set; }
            [JsonPropertyName("request_id")]
            public string? RequestId { get; set; }
            [JsonPropertyName("count")]
            public int Count { get; set; }
        }
        public class PolygonAgg
        {
            [JsonPropertyName("c")]
            public decimal Price { get; set; }
            // JAVÍTÁS: A Volume (v) néha tizedestört, ezért decimal-ként olvassuk be
            [JsonPropertyName("v")]
            public decimal Volume { get; set; } 
            [JsonPropertyName("t")]
            public long Timestamp { get; set; } // Unix MSEC timestamp
        }

        // Alpha Vantage TIME_SERIES_INTRADAY Response
        public class AlphaVantageResponse
        {
            [JsonPropertyName("Time Series (60min)")]
            public Dictionary<string, AlphaVantageTimeSeriesData>? TimeSeries { get; set; }
        }

        public class AlphaVantageTimeSeriesData
        {
            [JsonPropertyName("1. open")]
            public string? Open { get; set; }

            [JsonPropertyName("2. high")]
            public string? High { get; set; }

            [JsonPropertyName("3. low")]
            public string? Low { get; set; }

            [JsonPropertyName("4. close")]
            public string? Close { get; set; }

            [JsonPropertyName("5. volume")]
            public string? Volume { get; set; }
        }
    }
}
