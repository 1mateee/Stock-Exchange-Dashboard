using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using StockDashboard.Api.Data;
using StockDashboard.Api.Hubs;
using StockDashboard.Api.Models;

namespace StockDashboard.Api.Services
{
    public class StockUpdateService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IHubContext<StockHub> _hubContext;
        private readonly ILogger<StockUpdateService> _logger;
        private readonly List<string> _trackedSymbols = new() { "AAPL", "GOOGL", "MSFT", "TSLA", "AMZN", "META", "NVDA", "JPM", "V", "NFLX" };
        public StockUpdateService(
        IServiceProvider serviceProvider,
        IHubContext<StockHub> hubContext,
        ILogger<StockUpdateService> logger)
        {
            _serviceProvider = serviceProvider;
            _hubContext = hubContext;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await UpdateStockData();
                    await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken); // 60 másodperc
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating stock data");
                    await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
                }
            }
        }

        private async Task UpdateStockData()
        {
            using var scope = _serviceProvider.CreateScope();
            var stockDataService = scope.ServiceProvider.GetRequiredService<IStockDataService>();
            var dbContext = scope.ServiceProvider.GetRequiredService<StockDbContext>();

            var updatedStocks = new List<Stock>();

            foreach (var symbol in _trackedSymbols)
            {
                var stockData = await stockDataService.GetStockDataAsync(symbol);
                var existingStock = await dbContext.Stocks
                    .FirstOrDefaultAsync(s => s.Symbol == symbol);

                if (stockData != null)
                {
                    if (existingStock != null)
                    {
                        existingStock.CurrentPrice = stockData.CurrentPrice;
                        existingStock.Change = stockData.Change;
                        existingStock.ChangePercent = stockData.ChangePercent;
                        existingStock.Volume = stockData.Volume;
                        existingStock.LastUpdated = stockData.LastUpdated;
                        updatedStocks.Add(existingStock);
                    }
                    else
                    {
                        dbContext.Stocks.Add(stockData);
                        updatedStocks.Add(stockData);
                    }

                    // Történeti adat mentése
                    var history = new StockHistory
                    {
                        Symbol = stockData.Symbol,
                        Price = stockData.CurrentPrice,
                        Volume = stockData.Volume,
                        Timestamp = DateTime.UtcNow
                    };
                    dbContext.StockHistory.Add(history);

                    // Alert ellenőrzés
                    await CheckAlerts(dbContext, stockData);
                }
                else if (existingStock != null)
                {
                    // Fallback: használjuk a meglévő adatot
                    updatedStocks.Add(existingStock);
                    _logger.LogWarning("Fallback to cached data for {Symbol}", symbol);
                }
            }

            await dbContext.SaveChangesAsync();

            // SignalR értesítések küldése
            foreach (var stock in updatedStocks)
            {
                await _hubContext.Clients.Group($"stock_{stock.Symbol}")
                    .SendAsync("StockUpdated", stock);
            }

            await _hubContext.Clients.Group("all_stocks")
                .SendAsync("StocksUpdated", updatedStocks);

            _logger.LogInformation("Updated {Count} stocks at {Time}", updatedStocks.Count, DateTime.UtcNow);
        }

        private async Task CheckAlerts(StockDbContext dbContext, Stock stock)
        {
            var activeAlerts = await dbContext.StockAlerts
                .Where(a => a.Symbol == stock.Symbol && a.IsActive)
                .ToListAsync();

            foreach (var alert in activeAlerts)
            {
                bool shouldTrigger = alert.AlertType switch
                {
                    AlertType.PriceAbove => stock.CurrentPrice >= alert.TargetPrice,
                    AlertType.PriceBelow => stock.CurrentPrice <= alert.TargetPrice,
                    AlertType.PercentChangeAbove => stock.ChangePercent >= alert.TargetPrice,
                    AlertType.PercentChangeBelow => stock.ChangePercent <= alert.TargetPrice,
                    _ => false
                };

                if (shouldTrigger)
                {
                    alert.IsActive = false;
                    alert.TriggeredAt = DateTime.UtcNow;
                    alert.Message = $"Alert triggered: {stock.Symbol} is now {stock.CurrentPrice:C}";

                    await _hubContext.Clients.All
                        .SendAsync("AlertTriggered", alert);

                    _logger.LogInformation("Alert triggered for {Symbol}: {Message}", stock.Symbol, alert.Message);
                }
            }
        }
    }
}