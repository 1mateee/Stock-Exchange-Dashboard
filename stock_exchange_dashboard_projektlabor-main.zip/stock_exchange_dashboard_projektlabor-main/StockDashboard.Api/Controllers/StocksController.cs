using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockDashboard.Api.Data;
using StockDashboard.Api.Models;
using StockDashboard.Api.Services;

namespace StockDashboard.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StocksController : ControllerBase
    {
        private readonly StockDbContext _context;
        private readonly IStockDataService _stockDataService;
        private readonly ILogger<StocksController> _logger;

        public StocksController(
            StockDbContext context,
            IStockDataService stockDataService,
            ILogger<StocksController> logger)
        {
            _context = context;
            _stockDataService = stockDataService;
            _logger = logger;
        }

        // GET: api/stocks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Stock>>> GetStocks()
        {
            return await _context.Stocks.ToListAsync();
        }

        // GET: api/stocks/{symbol}?provider=Eodhd
        [HttpGet("{symbol}")]
        public async Task<ActionResult<Stock>> GetStock(string symbol, [FromQuery] StockApiProvider provider = StockApiProvider.Finnhub)
        {
            var stock = await _context.Stocks
                .FirstOrDefaultAsync(s => s.Symbol == symbol.ToUpper());

            if (stock == null)
            {
                stock = await _stockDataService.GetStockDataAsync(symbol.ToUpper(), provider);
                if (stock == null)
                {
                    return NotFound($"No data found for symbol {symbol} via {provider}");
                }
            }

            return stock;
        }

        // GET: api/stocks/{symbol}/history
        [HttpGet("{symbol}/history")]
        public async Task<ActionResult<IEnumerable<object>>> GetStockHistory(
            string symbol,
            [FromQuery] int days = 30)
        {
            try
            {
                _logger.LogInformation("Getting {Days} days of history for {Symbol}", days, symbol);

                // Limit days to reasonable range
                var limitedDays = Math.Min(Math.Max(days, 7), 365);

                // Use daily historical data for 7D and 30D+ charts
                // Calculate date range - go back further to ensure we have enough data
                var toDate = DateTime.UtcNow.Date;
                var fromDate = toDate.AddDays(-Math.Max(limitedDays * 4, 60)); // Go back even further for more data

                _logger.LogInformation("Fetching daily data from {FromDate} to {ToDate} (requested {Days} days)",
                    fromDate, toDate, limitedDays);

                // Get data from service
                var histories = await _stockDataService.GetHistoricalDataAsync(symbol.ToUpper(), fromDate, toDate, StockApiProvider.Eodhd);

                if (!histories.Any())
                {
                    _logger.LogWarning("No historical data found via EODHD for {Symbol} between {FromDate} and {ToDate}. Trying intraday fallback.",
                        symbol, fromDate, toDate);

                    // Fallback: use intraday (Yahoo) to at least provide recent data
                    var intraday = await _stockDataService.GetIntradayDataAsync(symbol.ToUpper());
                    if (intraday.Any())
                    {
                        // Reduce to one point per day (latest) to fit daily chart
                        histories = intraday
                            .GroupBy(h => h.Timestamp.Date)
                            .Select(g => g.OrderByDescending(x => x.Timestamp).First())
                            .OrderBy(h => h.Timestamp)
                            .ToList();

                        _logger.LogInformation("Using {Count} intraday fallback points for {Symbol}", histories.Count, symbol);
                    }
                }

                if (!histories.Any())
                {
                    _logger.LogWarning("No historical or intraday data available for {Symbol}; returning empty list.", symbol);
                    return Ok(Enumerable.Empty<object>());
                }

                _logger.LogInformation("Retrieved {Count} raw historical records", histories.Count);

                // Group by date and take the most recent entry for each day (handles multiple entries per day)
                var dailyData = histories
                    .Where(h => h.Timestamp.DayOfWeek >= DayOfWeek.Monday && h.Timestamp.DayOfWeek <= DayOfWeek.Friday)
                    .GroupBy(h => h.Timestamp.Date)
                    .Select(g => g.OrderByDescending(x => x.Timestamp).First()) // Take the latest entry for each day
                    .OrderByDescending(h => h.Timestamp.Date)
                    .ToList();

                _logger.LogInformation("Grouped to {Count} daily records", dailyData.Count);

                // Smart data sampling based on timeframe
                List<StockHistory> sampledData;

                if (limitedDays <= 7)
                {
                    // For 7D, get the last 7 trading days (one point per day)
                    sampledData = dailyData.Take(7).OrderBy(h => h.Timestamp).ToList();
                }
                else
                {
                    // For 30D+, get more recent data and sample intelligently
                    if (limitedDays <= 30)
                    {
                        // For 30D, get the last 30 trading days (one point per day)
                        sampledData = dailyData.Take(30).OrderBy(h => h.Timestamp).ToList();
                    }
                    else
                    {
                        // For longer periods, sample to reasonable number of points
                        var targetPoints = Math.Min(50, limitedDays);
                        var step = Math.Max(1, dailyData.Count / targetPoints);
                        sampledData = dailyData
                            .Where((item, index) => index % step == 0)
                            .Take(targetPoints)
                            .OrderBy(h => h.Timestamp)
                            .ToList();
                    }
                }

                // Format response for frontend
                var result = sampledData.Select(h => new
                {
                    date = h.Timestamp.ToString("yyyy-MM-dd"),
                    price = h.Price,
                    volume = h.Volume,
                    timestamp = ((DateTimeOffset)h.Timestamp).ToUnixTimeSeconds()
                }).ToList();

                _logger.LogInformation("Returning {Count} data points for {Symbol} ({Days} days requested)",
                    result.Count, symbol, limitedDays);

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting stock history for {Symbol}: {Message}", symbol, ex.Message);
                return StatusCode(500, $"Error retrieving stock history: {ex.Message}");
            }
        }

        // --- �J MET�DUS KEZDETE ---
        // GET: api/stocks/{symbol}/intraday
        [HttpGet("{symbol}/intraday")]
        public async Task<ActionResult<IEnumerable<object>>> GetStockIntraday(string symbol)
        {
            try
            {
                _logger.LogInformation("Getting intraday data for {Symbol}", symbol);

                // Ez a met�dus m�r l�tezik a StockDataService-ben
                var histories = await _stockDataService.GetIntradayDataAsync(symbol.ToUpper());

                if (histories == null || !histories.Any())
                {
                    _logger.LogWarning("No intraday data found for {Symbol}", symbol);
                    return NotFound($"No intraday data found for {symbol}");
                }

                // Az adatokat HH:mm formátumban adjuk vissza (időként az X-tengelyen)
                var result = histories.Select(h => new
                {
                    timestamp = h.Timestamp.ToString("HH:mm"),
                    price = h.Price,
                    volume = h.Volume
                }).ToList();

                _logger.LogInformation("Returning {Count} data points for {Symbol} (intraday)", result.Count, symbol);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting stock intraday for {Symbol}: {Message}", symbol, ex.Message);
                return StatusCode(500, $"Error retrieving stock intraday: {ex.Message}");
            }
        }
        // --- �J MET�DUS V�GEGE ---

        // POST: api/stocks/refresh/{symbol}?provider=Eodhd
        [HttpPost("refresh/{symbol}")]
        public async Task<ActionResult<Stock>> RefreshStock(string symbol, [FromQuery] StockApiProvider provider = StockApiProvider.Finnhub)
        {
            try
            {
                var stockData = await _stockDataService.GetStockDataAsync(symbol.ToUpper(), provider);
                if (stockData == null)
                {
                    return NotFound($"Could not fetch data for symbol {symbol} via {provider}");
                }

                var existingStock = await _context.Stocks
                    .FirstOrDefaultAsync(s => s.Symbol == symbol.ToUpper());

                if (existingStock != null)
                {
                    existingStock.CurrentPrice = stockData.CurrentPrice;
                    existingStock.Change = stockData.Change;
                    existingStock.ChangePercent = stockData.ChangePercent;
                    existingStock.Volume = stockData.Volume;
                    existingStock.LastUpdated = stockData.LastUpdated;
                }
                else
                {
                    _context.Stocks.Add(stockData);
                }

                await _context.SaveChangesAsync();
                return stockData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error refreshing stock data for {Symbol} via {Provider}", symbol, provider);
                return StatusCode(500, "An error occurred while refreshing stock data");
            }
        }

        // GET: api/stocks/search/{query}
        [HttpGet("search/{query}")]
        public async Task<ActionResult<IEnumerable<SearchSuggestion>>> SearchStocks(string query)
        {
            // 1) Local DB search
            var local = await _context.Stocks
                .Where(s => s.Symbol.Contains(query.ToUpper()) || s.CompanyName.Contains(query))
                .Select(s => new SearchSuggestion { Symbol = s.Symbol, CompanyName = s.CompanyName })
                .Take(10)
                .ToListAsync();

            // 2) External provider search (Finnhub), merge and de-duplicate
            var external = await _stockDataService.SearchSymbolsAsync(query);

            var map = new Dictionary<string, SearchSuggestion>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in local)
            {
                map[item.Symbol] = item;
            }
            foreach (var item in external)
            {
                if (!map.ContainsKey(item.Symbol))
                {
                    // Prefer description as company name if local entry is absent
                    map[item.Symbol] = new SearchSuggestion
                    {
                        Symbol = item.Symbol,
                        CompanyName = string.IsNullOrWhiteSpace(item.CompanyName) ? (item.Description ?? item.Symbol) : item.CompanyName,
                        Description = item.Description
                    };
                }
            }

            var merged = map.Values
                .OrderBy(s => local.Any(l => l.Symbol.Equals(s.Symbol, StringComparison.OrdinalIgnoreCase)) ? 0 : 1)
                .ThenBy(s => s.Symbol)
                .Take(10)
                .ToList();

            return merged;
        }
        // GET: api/stocks/{symbol}/history/eodhd?from=2025-09-01&to=2025-09-20
        [HttpGet("{symbol}/history/eodhd")]
        public async Task<ActionResult<IEnumerable<StockHistory>>> GetEodhdStockHistory(
            string symbol,
            [FromQuery] DateTime from,
            [FromQuery] DateTime to)
        {
            var histories = await _stockDataService.GetHistoricalDataAsync(symbol.ToUpper(), from, to, StockApiProvider.Eodhd);

            if (histories == null || histories.Count == 0)
                return NotFound($"No historical data found for {symbol} between {from:yyyy-MM-dd} and {to:yyyy-MM-dd}");

            return histories;
        }

        // GET: api/stocks/{symbol}/news
        [HttpGet("{symbol}/news")]
        public async Task<ActionResult<IEnumerable<object>>> GetCompanyNews(string symbol)
        {
            try
            {
                var news = await _stockDataService.GetCompanyNewsAsync(symbol.ToUpper());
                if (news == null || !news.Any())
                {
                    _logger.LogWarning("No company news found for {Symbol}", symbol);
                    return NotFound($"No company news found for {symbol}");
                }

                // Return a simplified shape
                var result = news.Select(n => new {
                    n.Category,
                    datetime = n.Datetime,
                    n.Headline,
                    n.Id,
                    n.Image,
                    n.Related,
                    n.Source,
                    n.Summary,
                    n.Url
                }).Take(10);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting company news for {Symbol}", symbol);
                return StatusCode(500, "Error retrieving company news");
            }
        }

        // GET: api/stocks/events/earnings?days=30
        [HttpGet("events/earnings")]
        public async Task<ActionResult<IEnumerable<FinnhubEarning>>> GetEarningsCalendar([FromQuery] int days = 30)
        {
            try
            {
                var fromDate = DateTime.UtcNow.Date;
                var toDate = fromDate.AddDays(days);

                var earnings = await _stockDataService.GetEarningsCalendarAsync(fromDate, toDate);
                if (earnings == null)
                {
                    return NotFound("Could not retrieve earnings calendar.");
                }

                _logger.LogInformation("Returning {Count} earnings events", earnings.Count);

                var trackedSymbols = await _context.Stocks.Select(s => s.Symbol).ToListAsync();
                var filteredEarnings = earnings
                    .Where(e => trackedSymbols.Contains(e.Symbol))
                    .OrderBy(e => e.Date)
                    .ToList();

                return Ok(filteredEarnings);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting earnings calendar");
                return StatusCode(500, "Error retrieving earnings calendar");
            }
        }
    }

}