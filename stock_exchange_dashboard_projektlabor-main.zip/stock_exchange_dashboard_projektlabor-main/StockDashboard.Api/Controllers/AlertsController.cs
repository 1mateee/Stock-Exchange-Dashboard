using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockDashboard.Api.Data;
using StockDashboard.Api.Models;

namespace StockDashboard.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlertsController : ControllerBase
    {
        private readonly StockDbContext _context;
        private readonly ILogger<AlertsController> _logger;

        public AlertsController(StockDbContext context, ILogger<AlertsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/alerts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StockAlert>>> GetAlerts()
        {
            return await _context.StockAlerts
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();
        }

        // GET: api/alerts/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<StockAlert>> GetAlert(int id)
        {
            var alert = await _context.StockAlerts.FindAsync(id);

            if (alert == null)
            {
                return NotFound();
            }

            return alert;
        }

        // GET: api/alerts/active
        [HttpGet("active")]
        public async Task<ActionResult<IEnumerable<StockAlert>>> GetActiveAlerts()
        {
            return await _context.StockAlerts
                .Where(a => a.IsActive)
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();
        }

        // GET: api/alerts/symbol/{symbol}
        [HttpGet("symbol/{symbol}")]
        public async Task<ActionResult<IEnumerable<StockAlert>>> GetAlertsBySymbol(string symbol)
        {
            return await _context.StockAlerts
                .Where(a => a.Symbol == symbol.ToUpper())
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();
        }

        // POST: api/alerts
        [HttpPost]
        public async Task<ActionResult<StockAlert>> CreateAlert(CreateAlertRequest request)
        {
            var alert = new StockAlert
            {
                Symbol = request.Symbol.ToUpper(),
                TargetPrice = request.TargetPrice,
                AlertType = request.AlertType,
                UserId = request.UserId ?? "anonymous",
                CreatedAt = DateTime.UtcNow
            };

            _context.StockAlerts.Add(alert);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Created alert for {Symbol} with target {Target}", 
                alert.Symbol, alert.TargetPrice);

            return CreatedAtAction(nameof(GetAlert), new { id = alert.Id }, alert);
        }

        // PUT: api/alerts/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAlert(int id, UpdateAlertRequest request)
        {
            var alert = await _context.StockAlerts.FindAsync(id);
            if (alert == null)
            {
                return NotFound();
            }

            alert.TargetPrice = request.TargetPrice ?? alert.TargetPrice;
            alert.AlertType = request.AlertType ?? alert.AlertType;
            alert.IsActive = request.IsActive ?? alert.IsActive;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/alerts/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAlert(int id)
        {
            var alert = await _context.StockAlerts.FindAsync(id);
            if (alert == null)
            {
                return NotFound();
            }

            _context.StockAlerts.Remove(alert);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Deleted alert {Id} for {Symbol}", id, alert.Symbol);

            return NoContent();
        }

        // POST: api/alerts/{id}/deactivate
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> DeactivateAlert(int id)
        {
            var alert = await _context.StockAlerts.FindAsync(id);
            if (alert == null)
            {
                return NotFound();
            }

            alert.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }

    // Request models
    public record CreateAlertRequest(
        string Symbol,
        decimal TargetPrice,
        AlertType AlertType,
        string? UserId = null
    );

    public record UpdateAlertRequest(
        decimal? TargetPrice = null,
        AlertType? AlertType = null,
        bool? IsActive = null
    );
}
