namespace StockDashboard.Api.Models
{
    public class StockHistory
    {
        public int Id { get; set; }
        public string Symbol { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public long Volume { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
