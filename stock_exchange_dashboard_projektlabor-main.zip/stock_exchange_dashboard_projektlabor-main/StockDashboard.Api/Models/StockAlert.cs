namespace StockDashboard.Api.Models
{
    public class StockAlert
    {
        public int Id { get; set; }
        public string Symbol { get; set; } = string.Empty;
        public decimal TargetPrice { get; set; }
        public AlertType AlertType { get; set; }
        public string UserId { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public DateTime? TriggeredAt { get; set; }
        public string? Message { get; set; }
    }

    public enum AlertType
    {
        PriceAbove,
        PriceBelow,
        PercentChangeAbove,
        PercentChangeBelow
    }
}
