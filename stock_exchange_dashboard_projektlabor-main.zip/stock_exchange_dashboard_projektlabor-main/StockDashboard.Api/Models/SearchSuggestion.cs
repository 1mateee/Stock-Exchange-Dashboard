namespace StockDashboard.Api.Models
{
    public class SearchSuggestion
    {
        public string Symbol { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
