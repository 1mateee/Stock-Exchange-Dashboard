using Microsoft.AspNetCore.SignalR;
using StockDashboard.Api.Models;

namespace StockDashboard.Api.Hubs
{
    public class StockHub : Hub
    {
        public async Task JoinStockGroup(string symbol)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, $"stock_{symbol}");
        }

        public async Task LeaveStockGroup(string symbol)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"stock_{symbol}");
        }

        public async Task JoinAllStocksGroup()
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, "all_stocks");
        }

        public async Task LeaveAllStocksGroup()
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "all_stocks");
        }
    }
}
